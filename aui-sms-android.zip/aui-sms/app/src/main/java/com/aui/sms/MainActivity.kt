package com.aui.sms

import android.Manifest
import android.app.AlertDialog
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.WebView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var bridge: Bridge
    private var loaded = false
    private var pending: String? = null
    private val prefs by lazy { getPreferences(MODE_PRIVATE) }

    private val perms: List<String> get() = buildList {
        add(Manifest.permission.READ_SMS); add(Manifest.permission.SEND_SMS); add(Manifest.permission.RECEIVE_SMS)
        add(Manifest.permission.RECEIVE_MMS); add(Manifest.permission.READ_CONTACTS); add(Manifest.permission.READ_PHONE_STATE)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }
    private val permL = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { askRole(false); js("window.refresh&&refresh()") }
    private val roleL = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { js("window.refresh&&refresh()") }

    private var locCb: ((android.location.Location?) -> Unit)? = null
    private val locL = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.any { it }) fetchLoc() else { locCb?.invoke(null); locCb = null }
    }

    fun getLocation(cb: (android.location.Location?) -> Unit) {
        locCb = cb
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) fetchLoc()
        else locL.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    @Suppress("MissingPermission")
    private fun fetchLoc() {
        val cb = locCb ?: return; locCb = null
        val lm = getSystemService(android.location.LocationManager::class.java)
        val provs = lm.getProviders(true)
        val last = provs.mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: Exception) { null } }.maxByOrNull { it.time }
        val p = provs.firstOrNull { it != "passive" }
        if (last != null) cb(last)
        else if (Build.VERSION.SDK_INT >= 30 && p != null) lm.getCurrentLocation(p, null, mainExecutor) { cb(it) }
        else cb(null)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this); setContentView(web)
        bridge = Bridge(this)
        Web.setup(web, bridge) { loaded = true; pending?.let { js(it) }; pending = null }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { web.evaluateJavascript("(window.nativeBack&&window.nativeBack())?1:0") { if (it != "1") finish() } }
        })
        handle(intent)
        val need = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isEmpty()) askRole(false)
        else AlertDialog.Builder(this).setTitle("AUI SMS").setCancelable(false)
            .setMessage("To read and send messages AUI SMS needs SMS, Contacts and Notifications access. Everything stays on your phone.")
            .setPositiveButton("Continue") { _, _ -> permL.launch(need.toTypedArray()) }.show()
    }

    override fun onStart() { super.onStart(); Events.cb = { js("window.refresh&&refresh()") } }
    override fun onStop() { Events.cb = null; super.onStop() }
    override fun onResume() { super.onResume(); js("window.refresh&&refresh()") }
    override fun onDestroy() { bridge.release(); super.onDestroy() }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handle(intent) }

    private fun handle(i: Intent?) {
        i ?: return
        fun q(s: String): String = JSONObject.quote(s)
        val s = when {
            i.hasExtra("addr") -> "window.nativeOpen&&nativeOpen(${q(i.getStringExtra("addr") ?: "")})"
            i.hasExtra("gid") -> "window.nativeOpenG&&nativeOpenG(${q(i.getStringExtra("gid") ?: "")})"
            i.action == Intent.ACTION_SENDTO || i.action == Intent.ACTION_VIEW -> {
                val n = i.data?.schemeSpecificPart?.substringBefore('?') ?: ""
                val b = i.getStringExtra("sms_body") ?: i.getStringExtra(Intent.EXTRA_TEXT) ?: ""
                "window.nativeCompose&&nativeCompose(${q(n)},${q(b)})"
            }
            i.action == Intent.ACTION_SEND -> "window.nativeCompose&&nativeCompose('',${q(i.getStringExtra(Intent.EXTRA_TEXT) ?: "")})"
            else -> return
        }
        if (loaded) js(s) else pending = s
    }

    private fun js(s: String) { if (::web.isInitialized) web.evaluateJavascript(s, null) }

    fun askRole(force: Boolean) {
        val rm = getSystemService(RoleManager::class.java)
        if (!rm.isRoleAvailable(RoleManager.ROLE_SMS) || rm.isRoleHeld(RoleManager.ROLE_SMS)) return
        if (!force && prefs.getBoolean("asked", false)) return
        prefs.edit().putBoolean("asked", true).apply()
        roleL.launch(rm.createRequestRoleIntent(RoleManager.ROLE_SMS))
    }
}
