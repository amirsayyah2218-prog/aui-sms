package com.aui.sms

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

class Db(c: Context) : SQLiteOpenHelper(c, "aui.db", null, 1) {
    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE grp(id TEXT PRIMARY KEY,name TEXT,adm TEXT,mem TEXT,st TEXT,ts INTEGER)")
        d.execSQL("CREATE TABLE gm(id TEXT PRIMARY KEY,gid TEXT,num TEXT,body TEXT,ts INTEGER,o INTEGER,rd INTEGER)")
        d.execSQL("CREATE TABLE sch(id TEXT PRIMARY KEY,ts INTEGER,kind TEXT,tgt TEXT,body TEXT,rep TEXT,st TEXT)")
    }
    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    fun rows(sql: String, vararg a: String): JSONArray {
        val out = JSONArray()
        readableDatabase.rawQuery(sql, a).use { c ->
            while (c.moveToNext()) {
                val o = JSONObject()
                for (i in 0 until c.columnCount)
                    o.put(c.getColumnName(i), when (c.getType(i)) {
                        Cursor.FIELD_TYPE_INTEGER -> c.getLong(i)
                        Cursor.FIELD_TYPE_NULL -> JSONObject.NULL
                        else -> c.getString(i)
                    })
                out.put(o)
            }
        }
        return out
    }

    companion object {
        @Volatile private var i: Db? = null
        fun get(c: Context): Db = i ?: synchronized(this) { i ?: Db(c.applicationContext).also { i = it } }
    }
}
