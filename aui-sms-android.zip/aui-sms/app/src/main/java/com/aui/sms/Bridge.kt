package com.aui.sms

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.Intent as I2
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Settings
import android.provider.Telephony
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.database.Cursor
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.core.view.WindowCompat
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject

/** Native functions exposed to the web UI as window.AuiBridge. All data stays on the device. */
class Bridge(private val act: Activity) {
    var web: WebView? = null
    private val ctx: Context = act.applicationContext
    private val db get() = Db.get(ctx)
    private val sp = ctx.getSharedPreferences("aui", Context.MODE_PRIVATE)
    private fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun ui(f: () -> Unit) = act.runOnUiThread(f)
    private fun launch(i: Intent) = ui { try { act.startActivity(i) } catch (e: Exception) {} }
    private fun clean(n: String) = n.filter { it.isDigit() || it == '+' }
    private fun Cursor.s(i: Int) = getString(i) ?: ""

    // ---- SMS provider ----
    @JavascriptInterface fun threads(): String {
        val out = LinkedHashMap<Long, JSONObject>()
        if (!has(Manifest.permission.READ_SMS)) return "[]"
        val blk = Sms.blocked(ctx)
        try {
            ctx.contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf("_id", "thread_id", "address", "body", "date", "type", "read"),
                null, null, "date DESC LIMIT 3000")?.use { c ->
                while (c.moveToNext()) {
                    val t = c.getLong(1); val a = c.s(2)
                    if (blk.contains(Sms.k10(a))) continue
                    val o = out.getOrPut(t) { JSONObject().put("tid", t).put("addr", a).put("body", c.s(3)).put("ts", c.getLong(4)).put("type", c.getInt(5)).put("un", 0) }
                    if (c.getInt(5) == 1 && c.getInt(6) == 0) o.put("un", o.getInt("un") + 1)
                }
            }
        } catch (e: Exception) {}
        return JSONArray(out.values).toString()
    }

    /** Newest first; the UI reverses. */
    @JavascriptInterface fun messages(tid: Long): String {
        val out = JSONArray()
        if (!has(Manifest.permission.READ_SMS)) return "[]"
        try {
            ctx.contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf("_id", "body", "date", "type", "status", "sub_id"),
                "thread_id=?", arrayOf(tid.toString()), "date DESC LIMIT 400")?.use { c ->
                while (c.moveToNext()) out.put(JSONObject().put("id", c.getLong(0)).put("body", c.s(1)).put("ts", c.getLong(2)).put("type", c.getInt(3)).put("st", c.getInt(4)).put("sub", if (c.isNull(5)) -1 else c.getInt(5)))
            }
        } catch (e: Exception) {}
        return out.toString()
    }

    @JavascriptInterface fun contacts(): String {
        val out = JSONArray()
        if (!has(Manifest.permission.READ_CONTACTS)) return "[]"
        val seen = HashSet<String>()
        try {
            ctx.contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, "${Phone.DISPLAY_NAME} COLLATE NOCASE ASC")?.use { c ->
                while (c.moveToNext()) {
                    val p = c.s(1); if (!seen.add(c.s(0) + Sms.k10(p))) continue
                    out.put(JSONObject().put("n", c.s(0)).put("p", clean(p)))
                }
            }
        } catch (e: Exception) {}
        return out.toString()
    }

    @JavascriptInterface fun sendS(a: String, t: String, sub: Int): Long { val id = Sms.send(ctx, clean(a), t, true, sub); Events.fire(); return id }
    @JavascriptInterface fun sims(): String {
        val out = JSONArray()
        if (!has(Manifest.permission.READ_PHONE_STATE)) return "[]"
        try {
            ctx.getSystemService(android.telephony.SubscriptionManager::class.java).activeSubscriptionInfoList?.forEach {
                out.put(JSONObject().put("sub", it.subscriptionId).put("slot", it.simSlotIndex).put("name", (it.displayName ?: it.carrierName ?: "").toString()))
            }
        } catch (e: Exception) {}
        return out.toString()
    }
    @JavascriptInterface fun defSub(): Int = android.telephony.SubscriptionManager.getDefaultSmsSubscriptionId()
    @JavascriptInterface fun location() = ui {
        (act as? MainActivity)?.getLocation { l ->
            web?.evaluateJavascript(if (l == null) "window.onLoc&&onLoc(null,null)" else "window.onLoc&&onLoc(${l.latitude},${l.longitude})", null)
        }
    }
    @JavascriptInterface fun send(a: String, t: String): Long { val id = Sms.send(ctx, clean(a), t, true); Events.fire(); return id }
    @JavascriptInterface fun markRead(tid: Long) {
        try { ctx.contentResolver.update(Telephony.Sms.CONTENT_URI, android.content.ContentValues().apply { put("read", 1) }, "thread_id=? AND read=0", arrayOf(tid.toString())) } catch (e: Exception) {}
    }
    @JavascriptInterface fun delThread(tid: Long) { try { ctx.contentResolver.delete(Telephony.Sms.CONTENT_URI, "thread_id=?", arrayOf(tid.toString())) } catch (e: Exception) {} }
    @JavascriptInterface fun delMsg(id: Long) { try { ctx.contentResolver.delete(Telephony.Sms.CONTENT_URI, "_id=?", arrayOf(id.toString())) } catch (e: Exception) {} }
    @JavascriptInterface fun setBlocked(a: String, on: Boolean) {
        val s = HashSet(Sms.blocked(ctx)); val k = Sms.k10(a).ifEmpty { a }
        if (on) s.add(k) else s.remove(k)
        sp.edit().putStringSet("blk", s).apply()
    }
    @JavascriptInterface fun blockedList(): String = JSONArray(Sms.blocked(ctx).toList()).toString()

    // ---- groups ----
    @JavascriptInterface fun groups(): String = db.rows(
        "SELECT g.*, (SELECT body FROM gm WHERE gid=g.id ORDER BY ts DESC LIMIT 1) AS last, (SELECT MAX(ts) FROM gm WHERE gid=g.id) AS lts, " +
        "(SELECT COUNT(*) FROM gm WHERE gid=g.id AND o=0 AND rd=0) AS un FROM grp g ORDER BY COALESCE(lts, ts) DESC").toString()
    @JavascriptInterface fun gmsgs(gid: String): String {
        db.writableDatabase.execSQL("UPDATE gm SET rd=1 WHERE gid=?", arrayOf(gid))
        return db.rows("SELECT * FROM gm WHERE gid=? ORDER BY ts ASC", gid).toString()
    }
    private fun nums(j: String): List<String> { val a = JSONArray(j); return (0 until a.length()).map { clean(a.getString(it)) }.filter { it.isNotEmpty() }.distinct() }
    @JavascriptInterface fun gNew(name: String, n: String): String = Group.create(ctx, name, nums(n))
    @JavascriptInterface fun gUpdate(gid: String, name: String, n: String) = Group.update(ctx, gid, name, nums(n))
    @JavascriptInterface fun gSendS(gid: String, t: String, sub: Int) = Group.send(ctx, gid, t, sub)
    @JavascriptInterface fun gAccept(gid: String) { db.writableDatabase.execSQL("UPDATE grp SET st='ok' WHERE id=?", arrayOf(gid)); Events.fire() }
    @JavascriptInterface fun gLeave(gid: String) = Group.leave(ctx, gid)
    @JavascriptInterface fun gDel(gid: String) = Group.delete(ctx, gid)

    // ---- scheduled messages ----
    @JavascriptInterface fun schedList(): String = db.rows("SELECT * FROM sch ORDER BY ts ASC").toString()
    @JavascriptInterface fun schedAdd(id: String, ts: Long, kind: String, tgt: String, body: String, rep: String, sub: Int) { Sched.add(ctx, id, ts, kind, tgt, body, rep, sub); Events.fire() }
    @JavascriptInterface fun schedDel(id: String) { Sched.del(ctx, id); Events.fire() }
    @JavascriptInterface fun exactOk() = Build.VERSION.SDK_INT < 31 || ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
    @JavascriptInterface fun openExact() = launch(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}")))

    // ---- app ----
    @JavascriptInterface fun isDefault() = Sms.isDefault(ctx)
    @JavascriptInterface fun requestDefault() = ui { (act as? MainActivity)?.askRole(true) }
    @JavascriptInterface fun openAppSettings() = launch(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
    @JavascriptInterface fun dial(n: String) = launch(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", clean(n), null)))
    @JavascriptInterface fun copy(t: String) = ui { ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("", t)) }
    @JavascriptInterface fun finish() = ui { act.finish() }
    @JavascriptInterface fun setBars(light: Boolean) = ui {
        val c = if (light) 0xFFF2F6FB.toInt() else Color.BLACK
        act.window.statusBarColor = c; act.window.navigationBarColor = c
        WindowCompat.getInsetsController(act.window, act.window.decorView).apply { isAppearanceLightStatusBars = light; isAppearanceLightNavigationBars = light }
    }

    // ---- voice: speech recognition (assistant + call notes) and text-to-speech ----
    private var rec: SpeechRecognizer? = null
    private var recMode = ""
    private var recTag = "en-US"
    private var want = false
    private val hh = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private fun jsCall(s: String) = act.runOnUiThread { web?.evaluateJavascript(s, null) }
    private fun deliver(t: String, fin: Boolean) =
        jsCall("window.onSpeech&&window.onSpeech({mode:'$recMode',final:$fin,text:${JSONObject.quote(t)}})")

    @JavascriptInterface fun listen(tag: String, mode: String) = ui {
        if (!has(Manifest.permission.RECORD_AUDIO)) {
            act.requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 9)
            jsCall("window.onSpeechError&&window.onSpeechError('perm')"); return@ui
        }
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { jsCall("window.onSpeechError&&window.onSpeechError('na')"); return@ui }
        stopRecOnly(); recMode = mode; recTag = tag; want = true; startRec()
    }

    @JavascriptInterface fun stopListen() = ui { want = false; stopRecOnly() }

    private fun stopRecOnly() { try { rec?.stopListening(); rec?.destroy() } catch (e: Exception) {}; rec = null }
    private fun restart() { stopRecOnly(); hh.postDelayed({ if (want) startRec() }, 250) }

    private fun startRec() {
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onPartialResults(b: Bundle?) {
                b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { deliver(it, false) }
            }
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (t.isNotEmpty()) deliver(t, true)
                if (recMode == "note" && want) hh.post { restart() } else want = false
            }
            override fun onError(e: Int) {
                if (recMode == "note" && want && (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)) hh.post { restart() }
                else { want = false; jsCall("window.onSpeechError&&window.onSpeechError('$e')") }
            }
        })
        r.startListening(I2(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, recTag)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName))
    }

    @JavascriptInterface fun speak(text: String, tag: String) = ui {
        val go: () -> Unit = {
            tts?.language = Locale.forLanguageTag(tag)
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "va")
        }
        if (tts == null) tts = TextToSpeech(ctx) { ttsReady = it == TextToSpeech.SUCCESS; if (ttsReady) go() }
        else if (ttsReady) go()
    }

    fun release() { want = false; stopRecOnly(); try { tts?.shutdown() } catch (e: Exception) {}; tts = null }

}
