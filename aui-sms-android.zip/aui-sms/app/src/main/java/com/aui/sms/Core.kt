package com.aui.sms

import android.app.*
import android.content.*
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Telephony
import android.telephony.SmsManager
import org.json.JSONArray
import java.util.Calendar
import java.util.concurrent.atomic.AtomicInteger

/** Native -> UI refresh hook. */
object Events {
    var cb: (() -> Unit)? = null
    fun fire() { Handler(Looper.getMainLooper()).post { cb?.invoke() } }
}

object Sms {
    const val SENT = "com.aui.sms.SENT"; const val DLV = "com.aui.sms.DLV"
    const val SCHED = "com.aui.sms.SCHED"; const val REPLY = "com.aui.sms.REPLY"; const val READ = "com.aui.sms.READ"
    private val seq = AtomicInteger(1000)
    private const val F = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

    fun isDefault(c: Context) = Telephony.Sms.getDefaultSmsPackage(c) == c.packageName
    fun k10(n: String) = n.filter { it.isDigit() }.takeLast(10)
    fun rid(n: Int): String { val a = "abcdefghijklmnopqrstuvwxyz0123456789"; return (1..n).map { a.random() }.joinToString("") }
    fun blocked(c: Context): Set<String> = c.getSharedPreferences("aui", Context.MODE_PRIVATE).getStringSet("blk", emptySet()) ?: emptySet()

    @Suppress("DEPRECATION")
    private fun mgr(c: Context): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    /** Sends [text]; when [log] and we are the default app the message is also stored in the system provider. */
    fun send(c: Context, num: String, text: String, log: Boolean): Long {
        var id = -1L
        if (log && isDefault(c)) try {
            val v = ContentValues().apply { put("address", num); put("body", text); put("date", System.currentTimeMillis()); put("read", 1); put("type", 4) }
            c.contentResolver.insert(Telephony.Sms.CONTENT_URI, v)?.let { id = ContentUris.parseId(it) }
        } catch (e: Exception) {}
        try {
            val m = mgr(c); val parts = m.divideMessage(text)
            val s = ArrayList<PendingIntent>(); val d = ArrayList<PendingIntent>()
            for (i in parts.indices) {
                val last = i == parts.size - 1
                fun mk(a: String) = PendingIntent.getBroadcast(c, seq.incrementAndGet(),
                    Intent(a).setClass(c, Rx::class.java).putExtra("id", id).putExtra("last", last), F)
                s.add(mk(SENT)); d.add(mk(DLV))
            }
            m.sendMultipartTextMessage(num, null, parts, s, d)
        } catch (e: Exception) { upd(c, id, 5, null) }
        return id
    }

    fun upd(c: Context, id: Long, type: Int?, status: Int?) {
        if (id < 0 || !isDefault(c)) return
        try {
            c.contentResolver.update(ContentUris.withAppendedId(Telephony.Sms.CONTENT_URI, id),
                ContentValues().apply { type?.let { put("type", it) }; status?.let { put("status", it) } }, null, null)
        } catch (e: Exception) {}
        Events.fire()
    }

    fun incoming(c: Context, from: String, body: String, ts: Long, deliver: Boolean) {
        if (Group.handle(c, from, body)) { Events.fire(); return }
        if (!deliver) return                       // not the default app: the default app stores + notifies
        if (blocked(c).contains(k10(from))) return
        try {
            c.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI,
                ContentValues().apply { put("address", from); put("body", body); put("date", ts); put("read", 0) })
        } catch (e: Exception) {}
        note(c, from.hashCode(), Util.nameOf(c, from), body, "addr", from, from)
        Events.fire()
    }

    fun note(c: Context, nid: Int, title: String, text: String, key: String, v: String, replyTo: String?) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("msgs", "Messages", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(c, nid, Intent(c, MainActivity::class.java).putExtra(key, v)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP), F)
        val b = Notification.Builder(c, "msgs").setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(title).setContentText(text).setStyle(Notification.BigTextStyle().bigText(text))
            .setCategory(Notification.CATEGORY_MESSAGE).setAutoCancel(true).setContentIntent(open)
        if (replyTo != null) {
            val rp = PendingIntent.getBroadcast(c, nid, Intent(REPLY).setClass(c, Rx::class.java).putExtra("addr", replyTo).putExtra("nid", nid),
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            b.addAction(Notification.Action.Builder(Icon.createWithResource(c, android.R.drawable.ic_menu_send), "Reply", rp)
                .addRemoteInput(RemoteInput.Builder("txt").setLabel("Reply").build()).build())
            val rd = PendingIntent.getBroadcast(c, nid + 1, Intent(READ).setClass(c, Rx::class.java).putExtra("addr", replyTo).putExtra("nid", nid), F)
            b.addAction(Notification.Action.Builder(Icon.createWithResource(c, android.R.drawable.ic_menu_view), "Mark read", rd).build())
        }
        nm.notify(nid, b.build())
    }
}

/** Offline group chat over plain SMS. Wire format: "[G:<gid6>:<M|I|U|L>:<mid5>] payload". */
object Group {
    private val RX = Regex("^\\[G:([a-z0-9]{6}):([MILU]):([a-z0-9]{5})\\] ?([\\s\\S]*)$")
    fun wrap(gid: String, t: String, p: String) = "[G:$gid:$t:${Sms.rid(5)}] $p"
    private fun list(a: JSONArray) = (0 until a.length()).map { a.getString(it) }

    fun handle(c: Context, from: String, body: String): Boolean {
        val m = RX.find(body.trim()) ?: return false
        val gid = m.groupValues[1]; val t = m.groupValues[2]; val mid = m.groupValues[3]; val p = m.groupValues[4]
        val db = Db.get(c); val w = db.writableDatabase
        val g = db.rows("SELECT * FROM grp WHERE id=?", gid).optJSONObject(0)
        val parts = p.split("|", limit = 2)
        val others = (parts.getOrNull(1) ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }
        if (t == "I" || (t == "U" && g == null)) {
            if (g == null) {
                w.execSQL("INSERT INTO grp VALUES(?,?,?,?,?,?)", arrayOf(gid, parts[0], from, JSONArray(others + from).toString(), "inv", System.currentTimeMillis()))
                Sms.note(c, gid.hashCode(), parts[0], "Group invitation", "gid", gid, null)
            }
            return true
        }
        if (g == null) return false
        val mem = list(JSONArray(g.getString("mem")))
        if (mem.none { Sms.k10(it) == Sms.k10(from) }) return true
        when (t) {
            "M" -> {
                val v = ContentValues().apply { put("id", gid + mid); put("gid", gid); put("num", from); put("body", p); put("ts", System.currentTimeMillis()); put("o", 0); put("rd", 0) }
                if (w.insertWithOnConflict("gm", null, v, android.database.sqlite.SQLiteDatabase.CONFLICT_IGNORE) != -1L)
                    Sms.note(c, gid.hashCode(), g.getString("name"), Util.nameOf(c, from) + ": " + p, "gid", gid, null)
            }
            "U" -> if (Sms.k10(g.getString("adm")) == Sms.k10(from))
                w.execSQL("UPDATE grp SET name=?,mem=? WHERE id=?", arrayOf(parts[0], JSONArray(others + from).toString(), gid))
            "L" -> w.execSQL("UPDATE grp SET mem=? WHERE id=?", arrayOf(JSONArray(mem.filter { Sms.k10(it) != Sms.k10(from) }).toString(), gid))
        }
        return true
    }

    private fun announce(c: Context, gid: String, t: String, name: String, nums: List<String>) {
        for (n in nums) Sms.send(c, n, wrap(gid, t, name + "|" + (nums - n).joinToString(",")), false)
    }

    fun create(c: Context, name: String, nums: List<String>): String {
        val gid = Sms.rid(6)
        Db.get(c).writableDatabase.execSQL("INSERT INTO grp VALUES(?,?,?,?,?,?)", arrayOf(gid, name, "", JSONArray(nums).toString(), "ok", System.currentTimeMillis()))
        announce(c, gid, "I", name, nums); Events.fire(); return gid
    }

    fun update(c: Context, gid: String, name: String, nums: List<String>) {
        Db.get(c).writableDatabase.execSQL("UPDATE grp SET name=?,mem=? WHERE id=?", arrayOf(name, JSONArray(nums).toString(), gid))
        announce(c, gid, "U", name, nums); Events.fire()
    }

    fun send(c: Context, gid: String, text: String) {
        val db = Db.get(c)
        val g = db.rows("SELECT * FROM grp WHERE id=?", gid).optJSONObject(0) ?: return
        val mid = Sms.rid(5)
        val v = ContentValues().apply { put("id", gid + mid); put("gid", gid); put("num", ""); put("body", text); put("ts", System.currentTimeMillis()); put("o", 1); put("rd", 1) }
        db.writableDatabase.insert("gm", null, v)
        for (n in list(JSONArray(g.getString("mem")))) Sms.send(c, n, "[G:$gid:M:$mid] $text", false)
        Events.fire()
    }

    fun leave(c: Context, gid: String) {
        val db = Db.get(c)
        db.rows("SELECT mem FROM grp WHERE id=?", gid).optJSONObject(0)?.let { g ->
            for (n in list(JSONArray(g.getString("mem")))) Sms.send(c, n, wrap(gid, "L", ""), false)
        }
        delete(c, gid)
    }

    fun delete(c: Context, gid: String) {
        val w = Db.get(c).writableDatabase
        w.execSQL("DELETE FROM grp WHERE id=?", arrayOf(gid)); w.execSQL("DELETE FROM gm WHERE gid=?", arrayOf(gid)); Events.fire()
    }
}

/** Timed messages: persisted in SQLite, fired by AlarmManager, re-armed after reboot. */
object Sched {
    private fun pi(c: Context, id: String) = PendingIntent.getBroadcast(c, id.hashCode(),
        Intent(Sms.SCHED).setClass(c, Rx::class.java).putExtra("id", id), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    fun add(c: Context, id: String, ts: Long, kind: String, tgt: String, body: String, rep: String) {
        Db.get(c).writableDatabase.execSQL("INSERT OR REPLACE INTO sch VALUES(?,?,?,?,?,?,?)", arrayOf(id, ts, kind, tgt, body, rep, "p"))
        arm(c, id, ts)
    }

    private fun arm(c: Context, id: String, ts: Long) {
        val am = c.getSystemService(AlarmManager::class.java); val p = pi(c, id)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ts, p)
            else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ts, p)
        } catch (e: SecurityException) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ts, p) }
    }

    fun del(c: Context, id: String) {
        c.getSystemService(AlarmManager::class.java).cancel(pi(c, id))
        Db.get(c).writableDatabase.execSQL("DELETE FROM sch WHERE id=?", arrayOf(id))
    }

    fun fire(c: Context, id: String) {
        val db = Db.get(c); val w = db.writableDatabase
        val r = db.rows("SELECT * FROM sch WHERE id=?", id).optJSONObject(0) ?: return
        if (r.getString("st") != "p") return
        val body = r.getString("body"); val tgt = r.getString("tgt")
        try {
            if (r.getString("kind") == "g") Group.send(c, tgt, body)
            else tgt.split(",").filter { it.isNotBlank() }.forEach { Sms.send(c, it.trim(), body, true) }
        } catch (e: Exception) { w.execSQL("UPDATE sch SET st='f' WHERE id=?", arrayOf(id)); Events.fire(); return }
        val rep = r.getString("rep")
        if (rep.isEmpty()) w.execSQL("UPDATE sch SET st='s' WHERE id=?", arrayOf(id))
        else {
            var n = r.getLong("ts"); val cal = Calendar.getInstance()
            do {
                cal.timeInMillis = n
                when (rep) { "d" -> cal.add(Calendar.DAY_OF_YEAR, 1); "w" -> cal.add(Calendar.WEEK_OF_YEAR, 1); "m" -> cal.add(Calendar.MONTH, 1); else -> cal.add(Calendar.YEAR, 1) }
                n = cal.timeInMillis
            } while (n <= System.currentTimeMillis())
            w.execSQL("UPDATE sch SET ts=? WHERE id=?", arrayOf(n, id)); arm(c, id, n)
        }
        Events.fire()
    }

    fun boot(c: Context) {
        val db = Db.get(c); val rows = db.rows("SELECT * FROM sch WHERE st='p'"); val now = System.currentTimeMillis()
        for (i in 0 until rows.length()) {
            val r = rows.getJSONObject(i); val ts = r.getLong("ts"); val id = r.getString("id")
            if (ts > now) arm(c, id, ts)
            else if (now - ts < 6 * 3600_000L) fire(c, id)
            else db.writableDatabase.execSQL("UPDATE sch SET st='f' WHERE id=?", arrayOf(id))
        }
    }
}

class SmsRx : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val deliver = i.action == Telephony.Sms.Intents.SMS_DELIVER_ACTION
        if (!deliver && Sms.isDefault(c)) return
        val ms = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        ms.groupBy { it.displayOriginatingAddress ?: "" }.forEach { (a, l) ->
            Sms.incoming(c, a, l.joinToString("") { it.displayMessageBody ?: "" }, l[0].timestampMillis, deliver)
        }
    }
}

class MmsRx : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) {} }

class RespondSvc : Service() {
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        val n = i?.data?.schemeSpecificPart?.substringBefore('?'); val t = i?.getStringExtra(Intent.EXTRA_TEXT)
        if (!n.isNullOrEmpty() && !t.isNullOrEmpty()) Sms.send(this, n, t, true)
        stopSelf(); return START_NOT_STICKY
    }
}

class Rx : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        when (i.action) {
            Sms.SENT -> {
                val id = i.getLongExtra("id", -1)
                if (resultCode != Activity.RESULT_OK) Sms.upd(c, id, 5, null)
                else if (i.getBooleanExtra("last", false)) Sms.upd(c, id, 2, null)
            }
            Sms.DLV -> if (i.getBooleanExtra("last", false)) Sms.upd(c, i.getLongExtra("id", -1), null, 0)
            Sms.SCHED -> Sched.fire(c, i.getStringExtra("id") ?: return)
            Sms.REPLY -> {
                val t = RemoteInput.getResultsFromIntent(i)?.getCharSequence("txt")?.toString()
                val a = i.getStringExtra("addr")
                if (!t.isNullOrBlank() && a != null) Sms.send(c, a, t, true)
                c.getSystemService(NotificationManager::class.java).cancel(i.getIntExtra("nid", 0))
            }
            Sms.READ -> {
                val a = i.getStringExtra("addr") ?: return
                try { c.contentResolver.update(Telephony.Sms.CONTENT_URI, ContentValues().apply { put("read", 1) }, "address=?", arrayOf(a)) } catch (e: Exception) {}
                c.getSystemService(NotificationManager::class.java).cancel(i.getIntExtra("nid", 0)); Events.fire()
            }
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> Sched.boot(c)
        }
    }
}
