/* AUI brain — everything offline: smart replies, time parsing, voice commands, Jalali calendar. */
(function(G){'use strict';
const ND=s=>String(s==null?'':s).replace(/[۰-۹]/g,c=>c.charCodeAt(0)-1776).replace(/[٠-٩]/g,c=>c.charCodeAt(0)-1632);
const NN=s=>ND(s).toLowerCase().replace(/ي/g,'ی').replace(/ك/g,'ک').replace(/\u200c/g,' ').replace(/[\u064B-\u065F\u200e\u200f]/g,'').replace(/[“”«»"'’.,!?؟،;()\[\]\-_*]/g,' ').replace(/:(?!\d)|(?<!\d):/g,' ').replace(/\s+/g,' ').trim();
const FA=s=>/[\u0600-\u06ff]/.test(s),Z=s=>s.replace(/~/g,'\u200c');
function lev(a,b){const m=[];for(let i=0;i<=a.length;i++)m[i]=[i];for(let j=1;j<=b.length;j++)m[0][j]=j;for(let i=1;i<=a.length;i++)for(let j=1;j<=b.length;j++)m[i][j]=Math.min(m[i-1][j]+1,m[i][j-1]+1,m[i-1][j-1]+(a[i-1]===b[j-1]?0:1));return m[a.length][b.length]}

/* ---------- smart replies ---------- */
const PROMO=/https?:\/\/|www\.|تخفیف|فروش ویژه|لغو ?11|discount|unsubscribe|promo/i;
function codeOf(t){const s=ND(t),m=s.match(/(?:کد|رمز|code|otp|pin|password|پسورد|تایید|تأیید|verification)[^\d]{0,40}(\d{4,8})|(\d{4,8})[^\d]{0,25}(?:is your|کد|رمز|code)/i);return m?(m[1]||m[2]):''}
const RULES=[
['condo',/تسلیت|درگذشت|فوت شد|رحمت|مرحوم|condolence|passed away|your loss|\brip\b/,
 ['خدا رحمتشون کنه 🤲','تسلیت عرض می~کنم، خدا صبرتون بده','روحشان شاد و یادشان گرامی'],['I am so sorry for your loss','My deepest condolences','Thinking of you and your family']],
['urgent',/فوری|اورژانس|urgent|asap|emergency/,['الان تماس می~گیرم','چی شده؟ در خدمتم','الان میام'],['Calling you now','What happened?','On my way']],
['congrats',/تبریک|مبارک|تولدت|تولد |سال نو|congrat|happy birthday|happy new year|eid/,['ممنون، لطف دارید 🌹','مبارک شما هم باشه','سلامت باشید، همچنین'],['Thank you so much!','Thanks, same to you!','That is so kind of you']],
['thanks',/ممنون|مرسی|تشکر|دستت درد نکنه|دمت گرم|سپاس|thanks|thank you|thx|appreciate/,['خواهش می~کنم 🌸','قابلی نداشت','وظیفه بود'],['You are welcome!','Anytime','No problem']],
['sorry',/ببخشید|عذر|متاسف|sorry|apolog/,['اشکالی نداره','نه بابا، مهم نیست','فراموشش کن'],['No worries','It is okay','Do not worry about it']],
['love',/دلم (?:برات|برایت|براتون) تنگ|دوستت دارم|miss you|love you/,['منم دلم برات تنگ شده ❤️','منم دوستت دارم','زودتر ببینمت'],['Miss you too ❤️','Love you too','See you soon']],
['salam',/سلام علیکم|سلام و علیکم|علیکم السلام/,['علیکم السلام، خوبید؟','سلام علیکم، وقت بخیر','سلام و رحمة الله'],['Peace be upon you too','Hello, how are you?','Hi there']],
['bye',/خداحافظ|شب بخیر|خدانگهدار|فعلا|bye|good ?night|see you/,['شب بخیر، خوش بخوابی 🌙','خدانگهدار','فعلاً، مراقب خودت باش'],['Good night 🌙','Bye, take care','See you later']],
['call',/زنگ بزن|تماس بگیر|call me|give me a call|ring me/,['الان زنگ می~زنم','الان نمی~تونم صحبت کنم، بعداً زنگ می~زنم','بعد از ظهر تماس می~گیرم'],['Calling you now','Cannot talk right now, I will call later','I will call you this afternoon']],
['where',/کجایی|کجا هستی|کجایید|where are you|where r u/,['تو راهم','همین نزدیکی~ام','الان می~رسم'],['On my way','Almost there','Just around the corner']],
['coming',/میای|میرسی|راه افتادی|کی میرسی|کی میای|are you coming|when will you|\beta\b/,['آره، دارم میام','۱۰ دقیقه دیگه اونجام','یکم دیر می~رسم'],['Yes, I am coming','I will be there in 10 minutes','I might be a little late']],
['money',/واریز|کارت|پول|حساب|مبلغ|بدهی|تومان|ریال|payment|transfer|money|\bowe\b|\bpay\b/,['الان واریز می~کنم','شماره کارت رو بفرست','رسید رو می~فرستم'],['I will transfer it now','Send me the account details','I will send the receipt']],
['addr',/آدرس|لوکیشن|موقعیت|location|address/,['الان می~فرستم','آدرس دقیق رو بده لطفاً','کجا؟'],['Sending it now','Please send the exact address','Where exactly?']],
['how',/خوبی|چطوری|چطورید|حالت|احوال|خوبید|how are you|how r u|what s up|\bsup\b/,['خوبم، ممنون! تو چطوری؟','الحمدلله، شما خوبید؟','مرسی، سرپا هستم 😄'],['I am good, thanks! You?','Doing well, how about you?','All good here']],
['meet',/جلسه|قرار|ملاقات|دیدار|meeting|appointment|فردا|امروز|امشب|ساعت|tomorrow|tonight/,['باشه، قبوله 👍','بذار برنامه~م رو ببینم و خبر بدم','زمان دیگه~ای ممکنه؟'],['Sounds good 👍','Let me check my schedule','Could we do another time?']],
['busy',/مشغول|سرگرم|busy/,['باشه، هر وقت فرصت داشتی خبر بده','مشکلی نیست','بعداً صحبت می~کنیم'],['Sure, let me know when you are free','No problem','Talk later']],
['hi',/^(?:سلام|درود|hi|hello|hey|صبح بخیر|عصر بخیر|وقت بخیر|slm|salam)/,['سلام{n}! خوبی؟','سلام، وقت بخیر 🌿','درود، در خدمتم'],['Hi{n}! How are you?','Hello, good to hear from you','Hey!']],
['ok',/^(?:باشه|اوکی|ok|okay|حله|قبول|چشم)|قبوله|okay/,['👍','ممنون، هماهنگ شد','عالی'],['👍','Great, thanks','Perfect']],
['q',/qmark|آیا|میشه|می شه|میتونی|می تونی|میتونید|can you|could you|would you|will you|are you|do you/,['آره، حتماً','نه، متأسفانه نمی~شه','بذار ببینم، بعداً خبر می~دم'],['Yes, sure','Sorry, I cannot','Let me check and get back to you']]];
const FALL=[['باشه 👍','الان نمی~تونم، بعداً جواب می~دم','ممنون از پیامتون'],['Okay 👍','Cannot talk now, I will reply later','Thanks for your message']];
function personal(s,pairs){const A=new Set(s.split(' ').filter(x=>x.length>1));if(!A.size)return[];const r=[];
 for(const p of pairs){const B=new Set(p.t.split(' ').filter(x=>x.length>1));let i=0;A.forEach(x=>{if(B.has(x))i++});const sim=i/(A.size+B.size-i||1);if(sim>=.5)r.push([sim,p.r])}
 r.sort((a,b)=>b[0]-a[0]);const o=[];r.forEach(x=>{if(!o.includes(x[1]))o.push(x[1])});return o.slice(0,2)}
function learn(msgs){const out=[];for(let i=1;i<msgs.length;i++){const a=msgs[i-1],b=msgs[i];
 if(a.type===1&&b.type===2&&b.ts-a.ts<216e5&&a.body.length<160&&b.body.length<160&&b.body.length>1)out.push({t:NN(a.body),r:b.body})}return out}
function smart(text,o){o=o||{};const code=codeOf(text);if(code||PROMO.test(text))return{sug:[],code};
 const s=NN(text)+(/[?؟]/.test(text)?' qmark':''),fa=FA(text),out=personal(s,o.pairs||[]),nm=o.name&&!/\d/.test(o.name)?' '+o.name.split(' ')[0]:'';
 let hit=RULES.find(r=>r[1].test(s));const pool=hit?(fa?hit[2]:hit[3]):[];
 [...pool,...FALL[fa?0:1]].forEach(x=>{x=Z(x).replace('{n}',nm);if(out.length<3&&!out.includes(x))out.push(x)});
 return{sug:out.slice(0,3),code:''}}

/* ---------- time parsing ---------- */
const NUMW={'نیم':.5,'یه':1,'یک':1,'دو':2,'سه':3,'چهار':4,'پنج':5,'ده':10,'پانزده':15,'بیست':20,'سی':30,'half an':.5,'half a':.5,'an':1,'a':1};
function parseWhen(raw,now){now=now||new Date();const s=NN(raw);let rest=s,m,ts=null;
 const cut=x=>{rest=rest.replace(x,' ').replace(/\s+/g,' ').trim()};
 const rel=s.match(/(نیم|یه|یک|دو|سه|چهار|پنج|ده|پانزده|بیست|سی|\d+(?:\.\d+)?) ?(ساعت|دقیقه) ?(و نیم )?(?:دیگه|دیگر|بعد)/),en=s.match(/in (half an?|an?|\d+(?:\.\d+)?) ?(hour|hr|minute|min)s?/);
 if(rel||en){const r=rel||en,v=NUMW[r[1]]!==undefined?NUMW[r[1]]:parseFloat(r[1]),hr=/ساعت|hour|hr/.test(r[2]);
  ts=+now+(v*(hr?60:1)+(rel&&rel[3]?30:0))*6e4;cut(r[0])}
 else{let day=null;
  if(/پس ?فردا|day after tomorrow/.test(s)){day=2;cut(/پس ?فردا|day after tomorrow/)}
  else if(/فردا|tomorrow/.test(s)){day=1;cut(/فردا|tomorrow/)}
  else if(/امروز|today/.test(s)){day=0;cut(/امروز|today/)}
  const tonight=/امشب|tonight/.test(s);if(tonight){day=0;cut(/امشب|tonight/)}
  const apre=/(?:^| )(am|pm|صبح|ظهر|عصر|شب|بعد ?از ?ظهر)(?: |$)/;
  m=s.match(/(?:ساعت|at) ?(\d{1,2})(?::(\d{2}))?/)||s.match(/(\d{1,2}):(\d{2})/)||s.match(/(?:^| )(\d{1,2}) ?(am|pm)(?: |$)/);
  let ap=(s.match(apre)||[])[1]||'';
  if(m&&+m[1]<=24&&!(m[2]&&+m[2]>59)){let h=+m[1],mi=+(m[2]&&/^\d+$/.test(m[2])?m[2]:0);cut(m[0]);if(ap)cut(new RegExp('(?:^| )'+ap.replace(' ','')+'(?: |$)'));
   let hh=h;if(/pm|عصر|بعد|شب/.test(ap)&&hh<12)hh+=12;if(/am|صبح/.test(ap)&&hh===12)hh=0;if(ap==='ظهر'&&hh<6)hh+=12;if(ap==='شب'&&h===12)hh=0;if(tonight&&!ap&&hh<12)hh+=12;
   const d=new Date(now);d.setHours(hh,mi,0,0);if(day)d.setDate(d.getDate()+day);
   if(day===null||day===0)if(d<=now){if(!ap&&h<12){d.setHours(hh+12)}if(d<=now)d.setDate(d.getDate()+1)}
   ts=+d}
  else if(day!==null&&day>0){const d=new Date(now);d.setDate(d.getDate()+day);d.setHours(9,0,0,0);ts=+d}}
 return ts===null?null:{ts,rest:rest.replace(/^(?:و |ساعت )/,'').trim()}}

/* ---------- Jalali ---------- */
function g2j(gy,gm,gd){const g=[0,31,59,90,120,151,181,212,243,273,304,334],gy2=gm>2?gy+1:gy;
 let days=355666+365*gy+Math.floor((gy2+3)/4)-Math.floor((gy2+99)/100)+Math.floor((gy2+399)/400)+gd+g[gm-1],jy=-1595+33*Math.floor(days/12053);days%=12053;
 jy+=4*Math.floor(days/1461);days%=1461;if(days>365){jy+=Math.floor((days-1)/365);days=(days-1)%365}
 const jm=days<186?1+Math.floor(days/31):7+Math.floor((days-186)/30),jd=days<186?1+days%31:1+(days-186)%30;return[jy,jm,jd]}
function j2g(jy,jm,jd){jy+=1595;let days=-355668+365*jy+Math.floor(jy/33)*8+Math.floor((jy%33+3)/4)+jd+(jm<7?(jm-1)*31:(jm-7)*30+186),gy=400*Math.floor(days/146097);days%=146097;
 if(days>36524){gy+=100*Math.floor(--days/36524);days%=36524;if(days>=365)days++}
 gy+=4*Math.floor(days/1461);days%=1461;if(days>365){gy+=Math.floor((days-1)/365);days=(days-1)%365}
 let gd=days+1;const sal=[0,31,(gy%4==0&&gy%100!=0)||gy%400==0?29:28,31,30,31,30,31,31,30,31,30,31];let gm;for(gm=0;gm<13&&gd>sal[gm];gm++)gd-=sal[gm];return[gy,gm,gd]}

/* ---------- contacts + voice commands ---------- */
function score(n,q){n=NN(n);if(!n||!q)return 0;if(n===q)return 100;if(n.startsWith(q)||q.startsWith(n))return 80;if(n.includes(q)||q.includes(n))return 60;
 const qt=q.split(' '),nt=n.split(' '),ov=qt.filter(t=>t.length>1&&nt.some(x=>x===t||(t.length>3&&lev(x,t)<=1))).length;return ov?30+ov*10:0}
function findIn(q,list,key,min,k){q=NN(q);const r=list.map(c=>({c,s:score(c[key],q)})).filter(x=>x.s>=(min||30)&&(!k||NN(x.c[key]).split(' ').length===k||x.s===100)).sort((a,b)=>b.s-a.s);return r.length?r[0].c:null}
const SEND=['(?:پیام|پیامک|اس ?ام ?اس|اسمس)'],VB='(?:بده|بفرست|بزن|بنویس|ارسال کن)';
function split(tail,env){const t=tail.split(' ').filter(Boolean),num=tail.match(/\+?\d[\d ]{6,}\d/);
 if(num){const n=num[0].replace(/ /g,'');return{c:{n:n,p:n},name:n,body:tail.replace(num[0],' ').trim()}}
 const isG=/^(گروه|group) /.test(tail),t2=isG?t.slice(1):t;
 for(let k=Math.min(3,t2.length);k>=1;k--){const q=t2.slice(0,k).join(' ');
  if(isG){const g=findIn(q,env.groups||[],'name',60,k);if(g)return{g,name:g.name,body:t2.slice(k).join(' ')}}
  else{const c=findIn(q,env.contacts||[],'n',60,k);if(c)return{c,name:c.n,body:t2.slice(k).join(' ')}}}
 if(t2[0]){const c=isG?null:findIn(t2[0],env.contacts||[],'n',60),g=isG?findIn(t2[0],env.groups||[],'name',60):null;if(c||g)return{c,g,name:(c||g).n||(g||{}).name,body:t2.slice(1).join(' ')}}
 return{name:t2[0]||'',body:t2.slice(1).join(' ')}}
function parseCmd(text,env){env=env||{};const s=NN(text);let m;if(!s)return null;
 if(/^(?:بله|آره|اره|ارسال|ارسال کن|بفرست|تایید|حله|yes|send|send it|confirm|ok|okay)$/.test(s))return{t:'yes'};
 if(/^(?:نه|نخیر|لغو|بیخیال|cancel|no|stop)$/.test(s))return{t:'no'};
 if(/گروه جدید|ساخت گروه|new group|create group/.test(s))return{t:'newgroup'};
 if(/زمان ?دار|زمان ?بندی|scheduled/.test(s))return{t:'sched'};
 if(/(بخون|بخوان|بگو چی|read)/.test(s)&&/پیام|message|sms|text/.test(s)){const SW=new Set('پیام ها پیامک های جدید نخونده نخوانده آخرین رو را بخون بخوان برام بگو چی read my new unread last latest message messages from text texts sms the'.split(' ')),q=s.split(' ').filter(x=>!SW.has(x)).join(' ');
  return{t:'read',unread:/جدید|نخونده|نخوانده|unread|new/.test(s),c:q?findIn(q,env.contacts||[],'n'):null,q}}
 if(m=s.match(new RegExp('^(?:به|برای) (.+?) '+SEND+' '+VB+'(?: که| بگو)? ?(.*)$')))return Object.assign({t:'send'},split(m[1]+' '+m[2],env),m[1].match(/^(?:گروه|group) /)?{}:{},fixName(m[1],m[2],env));
 if(m=s.match(new RegExp('^'+SEND+' '+VB+' (?:به|برای) (.+)$')))return Object.assign({t:'send'},split(m[1],env));
 if(m=s.match(/^(?:send|text|message|sms)(?: a (?:message|text|sms))?(?: to)? (.+)$/)){let tl=m[1].replace(/ (?:saying|that|say) /,' ');return Object.assign({t:'send'},split(tl,env))}
 if(m=s.match(/^(?:جواب بده|جواب|پاسخ بده|reply|respond)(?: که| با| to)? (.+)$/))return{t:'reply',body:m[1]};
 if(m=s.match(/^(?:جستجو|پیدا کن|search|find) (.+)$/))return{t:'search',q:m[1]};
 if(m=s.match(/^(?:باز کن|بازش کن|برو به|open|go to|show)(?: گفتگو| چت| پیام های| chat| conversation| messages)?(?: با| از| with| from)? (.+)$/)){const q=m[1];const g=/^(?:گروه|group) /.test(q)?findIn(q.replace(/^\S+ /,''),env.groups||[],'name'):null;return g?{t:'open',g}:{t:'open',c:findIn(q,env.contacts||[],'n'),name:q}}
 return null}
function fixName(n,b,env){const r=split(n,env);return{c:r.c,g:r.g,name:r.name||n,body:b}}

G.Brain={ND,NN,FA,smart,learn,parseWhen,g2j,j2g,parseCmd,findIn,codeOf};
if(typeof module!=='undefined')module.exports=G.Brain;
})(typeof window!=='undefined'?window:globalThis);
