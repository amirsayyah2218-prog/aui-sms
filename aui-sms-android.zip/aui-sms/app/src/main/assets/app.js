/* AUI SMS — UI layer. Native bridge: window.AuiBridge. Pure logic lives in brain.js. Fully offline. */
window.onerror=(m,u,l)=>{const e=document.createElement('pre');e.style.cssText='position:fixed;z-index:99;top:60px;left:8px;right:8px;color:#ff8a8a;background:#000c;font-size:12px;white-space:pre-wrap';e.textContent='Error: '+m+' (line '+l+')';document.body.appendChild(e)};
const B=window.Brain,NB=window.AuiBridge||new Proxy({},{get:(_,k)=>()=>k==='isDefault'||k==='exactOk'?true:'[]'});
const $=s=>document.querySelector(s),esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])),uid=()=>Math.random().toString(36).slice(2,9);
const KEY='aui_sms1';let S;try{S=JSON.parse(localStorage.getItem(KEY))}catch(e){}
S=Object.assign({th:'dark',acc:'blue',gl:1,lg:'fa',cal:'p',sr:1,tts:1,pairs:[],pins:[],sim:-1},S||{});
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}};
const J=(f,...a)=>{try{return JSON.parse(NB[f](...a))}catch(e){return[]}};

/* ---------- i18n ---------- */
const FA={'Messages':'پیام‌ها','Groups':'گروه‌ها','Scheduled':'زمان‌دار','Chats':'گفتگوها','Assistant':'دستیار','All':'همه','Unread':'نخوانده','Search…':'جستجو…','You':'شما','Yesterday':'دیروز','Today':'امروز',
'New message':'پیام جدید','To':'به','Name or number':'نام یا شماره','Type a message…':'پیام را بنویسید…','Enter a recipient':'گیرنده را وارد کنید','Use number':'استفاده از شماره','No conversations yet':'هنوز گفتگویی نیست','No groups yet':'هنوز گروهی نیست','No scheduled messages':'پیام زمان‌داری نیست',
'Set AUI SMS as your default SMS app to send and receive messages.':'برای ارسال و دریافت پیام، AUI SMS را برنامه‌ی پیش‌فرض پیامک کنید.','Set default':'پیش‌فرض کن','Settings':'تنظیمات','Mark all as read':'همه را خوانده کن','New group':'گروه جدید','New schedule':'زمان‌بندی جدید',
'Copy':'کپی','Forward':'ارسال به دیگری','Delete':'حذف','Resend':'ارسال مجدد','Call':'تماس','Schedule message':'ارسال زمان‌دار','Block number':'مسدود کردن شماره','Unblock number':'رفع مسدودی','Delete conversation':'حذف گفتگو','Copied':'کپی شد','Deleted':'حذف شد','Blocked':'مسدود شد','Unblocked':'رفع مسدودی شد',
'Copy code':'کپی کد','Group name':'نام گروه','Create group':'ساخت گروه','Save':'ذخیره','Add number':'افزودن شماره','Search contacts…':'جستجوی مخاطبان…','selected':'انتخاب‌شده','Only people who also have AUI SMS can see group messages. Messages travel as normal SMS, no internet needed.':'فقط کسانی که AUI SMS دارند پیام گروه را می‌بینند. پیام‌ها با پیامک معمولی ارسال می‌شوند و اینترنت لازم نیست.',
'Group name and at least one member are required':'نام گروه و حداقل یک عضو لازم است','Up to 15 members':'حداکثر ۱۵ عضو','Group created':'گروه ساخته شد','Group updated':'گروه به‌روز شد','Invitation to this group. Accept to join.':'دعوت به این گروه. برای عضویت بپذیرید.','Accept':'پذیرفتن','Decline':'رد کردن','members':'عضو',
'Group info':'اطلاعات گروه','Edit group':'ویرایش گروه','Leave group':'ترک گروه','Delete group from this phone':'حذف گروه از این گوشی','Members':'اعضا','Admin':'مدیر',
'Message':'متن پیام','When':'زمان ارسال','Repeat':'تکرار','Never':'بدون تکرار','Daily':'روزانه','Weekly':'هفتگی','Monthly':'ماهانه','Yearly':'سالانه','In 10 min':'۱۰ دقیقه دیگر','In 1 hour':'۱ ساعت دیگر','Tonight 20:00':'امشب ۲۰:۰۰','Tomorrow 08:00':'فردا ۰۸:۰۰','Tomorrow 12:00':'فردا ۱۲:۰۰',
'Will send on':'ارسال در','Choose a recipient or group':'گیرنده یا گروه را انتخاب کنید','Write a message first':'اول پیام را بنویسید','Pick a time in the future':'زمانی در آینده انتخاب کنید','Scheduled':'زمان‌بندی شد','Pending':'در انتظار','Sent':'ارسال شد','Failed':'ناموفق','Send now':'همین حالا ارسال کن','Edit':'ویرایش','Cancel schedule':'لغو زمان‌بندی',
'Exact alarms are off, so timed messages may arrive a few minutes late.':'آلارم دقیق خاموش است؛ پیام‌های زمان‌دار ممکن است چند دقیقه دیرتر ارسال شوند.','Allow':'اجازه','Groups':'گروه‌ها','Schedule':'زمان‌بندی',
'Theme':'پوسته','Dark':'تیره','Light':'روشن','Auto':'خودکار','Accent':'رنگ تاکیدی','Blue':'آبی','Green':'سبز','Glass effect':'جلوه‌ی شیشه‌ای','Language':'زبان','Calendar':'تقویم','Jalali':'شمسی','Gregorian':'میلادی','Smart replies':'پاسخ‌های هوشمند','Read aloud':'خواندن با صدا',
'Default SMS app':'برنامه‌ی پیش‌فرض پیامک','Yes':'بله','No':'خیر','Make default':'پیش‌فرض کن','Blocked numbers':'شماره‌های مسدود','Unblock':'رفع','None':'هیچ','Forget learned replies':'فراموش کردن پاسخ‌های یادگرفته','Done':'انجام شد','Permissions':'دسترسی‌ها',
'How can I help you?':'چطور می‌تونم کمکت کنم؟','Listening…':'در حال گوش دادن…','Close':'بستن','Speak':'صحبت کن','Microphone permission is needed':'دسترسی میکروفون لازم است','Voice recognition is not available':'تشخیص گفتار در دسترس نیست','I did not catch that. Tap Speak to try again.':'متوجه نشدم. دکمه‌ی صحبت را بزنید.',
'Sorry, I did not understand':'متوجه نشدم','Cancelled':'لغو شد','Contact not found':'مخاطب پیدا نشد','Send':'ارسال','Message to':'پیام به','Send it?':'ارسال شود؟','Scheduled for':'زمان‌بندی شد برای','No new messages':'پیام جدیدی نیست','Message from':'پیام از','Nothing to reply to':'پیامی برای پاسخ نیست',
'Message sent':'پیام ارسال شد','Call Ali':'','Message Ali hello':'','Send Sara hi tomorrow at 8 am':'','Read my new messages':'','New group':'گروه جدید','No code':'','Dictate':'دیکته','Language of voice':'زبان صدا','Group':'گروه','Invitation':'دعوت','Group message':'پیام گروهی','Unknown':'ناشناس','SMS':'پیامک','Yellow':'زرد','Mono':'مشکی/سفید','Contact':'مخاطب','Date':'تاریخ','Location':'موقعیت مکانی','Getting location…':'در حال دریافت موقعیت…','Location unavailable':'موقعیت در دسترس نیست','Pick date & time…':'انتخاب تاریخ و ساعت…','Send later':'ارسال در زمان دلخواه','Insert':'درج','Reply':'پاسخ به این پیام','Reaction sent':'واکنش ارسال شد','Pin':'سنجاق کردن','Unpin':'برداشتن سنجاق','Mark read':'خوانده شد','Details':'جزئیات','Replying to':'پاسخ به','Status':'وضعیت'};
const L=s=>S.lg==='fa'&&FA[s]||s;
const fd=s=>S.lg==='fa'?String(s).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]):String(s);
const VEX={en:['Message Ali hello','Send Sara hi tomorrow at 8 am','Read my new messages','New group'],fa:['به علی پیام بده سلام','به مامان فردا ساعت ۸ صبح پیام بده بیا','پیام‌های جدید رو بخون','گروه جدید']};
const JM=['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];

/* ---------- icons ---------- */
const P={back:'<path d="M15 5l-7 7 7 7"/>',plus:'<path d="M12 5v14M5 12h14"/>',dots:'<circle cx="12" cy="5" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="12" cy="19" r="1.2"/>',search:'<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4-4"/>',
mic:'<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',send:'<path d="M3 11.5L21 3l-8 18-2.5-7.5z"/>',clock:'<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
phone:'<path d="M6.6 10.8a15 15 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.25 11.4 11.4 0 0 0 3.6.57 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.45.57 3.6a1 1 0 0 1-.25 1z"/>',
chat:'<path d="M4 5h16v11H9l-5 4z"/>',users:'<circle cx="9" cy="8.5" r="3"/><path d="M3 19c.4-3.2 2.8-5 6-5s5.6 1.8 6 5z"/><circle cx="17" cy="9.5" r="2.3"/><path d="M17 14.2c2.3 0 3.7 1.4 4 4.3"/>',
gear:'<circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/>',trash:'<path d="M5 7h14M9 7V4h6v3M7 7l1 13h8l1-13"/>',
copy:'<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',fwd:'<path d="M14 5l6 6-6 6M20 11H8a4 4 0 0 0-4 4v3"/>',block:'<circle cx="12" cy="12" r="8.5"/><path d="M6 6l12 12"/>',
check:'<path d="M5 12l5 5 9-10"/>',x:'<path d="M6 6l12 12M18 6L6 18"/>',edit:'<path d="M4 20h4L19 9l-4-4L4 16z"/>',spark:'<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/>',read:'<path d="M4 12l5 5L20 6M9 12l4 4"/>'};
P.pin='<path d="M9 4h6l-1 6 3 3H7l3-3zM12 13v7"/>';P.reply='<path d="M10 5L4 11l6 6M4 11h10a6 6 0 0 1 6 6v1"/>';
const ic=(n,s=22,f)=>`<svg class="${f?'flip':''}" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${P[n]}</svg>`;
const GL={A:['.###.','#...#','#...#','#####','#...#','#...#','#...#'],U:['#...#','#...#','#...#','#...#','#...#','#...#','.###.'],I:['.###.','..#..','..#..','..#..','..#..','..#..','.###.'],S:['.####','#....','#....','.###.','....#','....#','####.'],M:['#...#','##.##','#.#.#','#.#.#','#...#','#...#','#...#'],' ':['..','..','..','..','..','..','..']};
function dots(t){let x=0,o='';for(const ch of t){const g=GL[ch]||GL[' '];g.forEach((r,y)=>[...r].forEach((c,i)=>{if(c==='#')o+=`<circle cx="${(x+i)*3+1.5}" cy="${y*3+1.5}" r="1.15"/>`}));x+=g[0].length+1}return`<svg viewBox="0 0 ${x*3} 21" fill="currentColor" style="color:var(--ac)">${o}</svg>`}

/* ---------- formatting / data ---------- */
const jal=()=>S.lg==='fa'&&S.cal==='p',loc=()=>S.lg==='fa'?'fa-IR-u-ca-'+(S.cal==='p'?'persian':'gregory'):'en-US';
const tm=ts=>new Date(ts).toLocaleTimeString(S.lg==='fa'?'fa-IR':'en-US',{hour:'2-digit',minute:'2-digit',hour12:S.lg!=='fa'});
const dayd=ts=>Math.round((new Date(new Date().toDateString())-new Date(new Date(ts).toDateString()))/864e5);
const dfmt=(ts,o)=>new Intl.DateTimeFormat(loc(),o).format(ts);
const when=ts=>{const x=dayd(ts);return x<1?tm(ts):x<2?L('Yesterday'):dfmt(ts,{day:'numeric',month:'short'})};
const fdt=ts=>dfmt(ts,{month:'short',day:'numeric'})+' — '+tm(ts),full=ts=>dfmt(ts,{weekday:'long',day:'numeric',month:'long',year:'numeric'})+' — '+tm(ts);
const dayLabel=ts=>{const x=dayd(ts);return x<1?L('Today'):x<2?L('Yesterday'):dfmt(ts,{weekday:'long',day:'numeric',month:'long'})};
const k10=n=>B.ND(n).replace(/\D/g,'').slice(-10);
let TH=[],CT=[],GR=[],SC=[],VL=[],PL=[],SIMS=[],DEFSUB=-1,HC=0,tab='c',filt='all',cur=null,SF=null,GF=null;
const disp=a=>/^[+\d\s()\-]+$/.test(a||'')?`<bdi dir="ltr">${esc(a)}</bdi>`:esc(a),pinKey=a=>k10(a)||a,isPin=a=>S.pins.includes(pinKey(a)),isKnown=a=>!!k10(a)&&CT.some(c=>k10(c.p)===k10(a));
const simSlot=s=>{const x=SIMS.find(v=>v.sub===s);return x?x.slot+1:0},curSim=()=>SIMS.length<2?-1:(SIMS.find(s=>s.sub===S.sim)||SIMS.find(s=>s.sub===DEFSUB)||SIMS[0]).sub;
function simSync(){const b=$('#simb');if(!b)return;if(SIMS.length<2){b.style.display='none';return}b.style.display='grid';b.innerHTML=`<span style="font-size:10px;line-height:1.05;text-align:center">SIM<br><b style="font-size:15px">${fd(simSlot(curSim()))}</b></span>`}
const ins=t=>{const ta=$('#ta');if(!ta)return;ta.value=(ta.value&&!/\s$/.test(ta.value)?ta.value+' ':ta.value)+t;ta.focus();cnt()};
const snip=s=>s.replace(/^↪ «[^»]*»\n/,'').replace(/\s+/g,' ').slice(0,40);
const pres=()=>{const n=new Date(),pre=[[L('In 10 min'),+n+6e5],[L('In 1 hour'),+n+36e5]],t=new Date(n);t.setHours(20,0,0,0);if(t>n)pre.push([L('Tonight 20:00'),+t]);const a=new Date(n);a.setDate(a.getDate()+1);a.setHours(8,0,0,0);pre.push([L('Tomorrow 08:00'),+a]);const b=new Date(a);b.setHours(12);pre.push([L('Tomorrow 12:00'),+b]);return pre};
function nameOf(a){const k=k10(a);if(k.length>=7){const c=CT.find(c=>k10(c.p)===k);if(c)return c.n}return a}
function loadAll(){SIMS=J('sims');DEFSUB=Number(NB.defSub())||-1;TH=J('threads');if(!CT.length)CT=J('contacts');GR=J('groups');SC=J('schedList')}
const ini=s=>{s=(s||'#').trim();return/[a-z\u0600-\u06ff]/i.test(s[0]||'#')?s[0].toUpperCase():'#'};
const av=(n,k='',icon)=>`<div class="av ${k}">${icon?ic(icon,20):esc(ini(n))}</div>`;
const segs=t=>{const u=/[^\x00-\x7F]/.test(t),l=t.length;return l<=(u?70:160)?1:Math.ceil(l/(u?67:153))};
const tgtName=s=>s.kind==='g'?((GR.find(g=>g.id===s.tgt)||{}).name||L('Group')):s.tgt.split(',').map(nameOf).join('، ');

/* ---------- main screen ---------- */
function applySet(){const r=document.documentElement;r.dataset.th=S.th==='auto'?(matchMedia('(prefers-color-scheme: light)').matches?'light':'dark'):S.th;r.dataset.acc=S.acc;r.dataset.gl=S.gl?1:0;r.lang=S.lg;r.dir=S.lg==='fa'?'rtl':'ltr';try{NB.setBars(r.dataset.th==='light')}catch(e){}}
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(t.t);t.t=setTimeout(()=>t.classList.remove('on'),2200)}
function sheet(t,items,pre){$('#shc').innerHTML=(t?`<h4 style="padding:8px 14px;font-weight:500">${esc(t)}</h4>`:'')+(pre||'')+items.map(i=>`<button class="shi${i.r?' red':''}" data-a="${i.a}" ${Object.entries(i.d||{}).map(([k,v])=>`data-${k}="${esc(v)}"`).join(' ')}>${i.i?ic(i.i,20):''}${esc(i.t)}</button>`).join('');$('#shb').classList.add('on')}
const closeSh=()=>$('#shb').classList.remove('on');
function render(){
 $('#q').placeholder=L('Search…');
 for(const [id,n] of [['ic_mic','mic'],['ic_plus','plus'],['ic_dots','dots'],['ic_s','search']])$('#'+id).innerHTML=ic(n,id==='ic_s'?20:22);
 $('#ttl').textContent=L({c:'Messages',g:'Groups',s:'Scheduled'}[tab]);
 $('#seg').style.display=tab==='c'?'flex':'none';$('#seg').innerHTML=[['all','All'],['un','Unread'],['unk','Unknown']].map(x=>`<button data-a="filt" data-f="${x[0]}" class="${filt===x[0]?'on':''}">${L(x[1])}</button>`).join('');
 $('#sr').style.display=tab==='s'?'none':'flex';
 $('#nav').innerHTML=[['c','chat','Chats'],['g','users','Groups']].map(x=>navb(x)).join('')+`<button class="fab" data-a="newm" aria-label="New">${ic('plus',28)}</button>`+navb(['s','clock','Scheduled'])+`<button data-a="va">${ic('mic')}<span>${L('Assistant')}</span></button>`;
 const q=B.NN($('#q').value),def=NB.isDefault();let h='';
 if(tab==='c'){
  if(!def)h+=`<div class="banner g"><span>${L('Set AUI SMS as your default SMS app to send and receive messages.')}</span><button data-a="defapp">${L('Set default')}</button></div>`;
  VL=TH.filter(t=>(filt==='all'||(filt==='un'&&t.un>0)||(filt==='unk'&&!isKnown(t.addr)))&&(!q||B.NN(nameOf(t.addr)+' '+t.body).includes(q))).sort((a,b)=>isPin(b.addr)-isPin(a.addr));
  h+=VL.length?VL.map((t,i)=>`<div class="row" data-a="opent" data-lp="rowmenu" data-i="${i}">${av(nameOf(t.addr))}<div class="in"><div class="nm">${disp(nameOf(t.addr))}${isPin(t.addr)?' '+ic('pin',13):''}</div><div class="mt">${t.type>=2&&t.type!==3?L('You')+': ':''}${esc(t.body.replace(/\n/g,' '))}</div></div><div style="text-align:end"><div class="mt">${when(t.ts)}</div>${t.un?`<span class="badge">${fd(t.un)}</span>`:''}</div></div>`).join(''):`<div class="empty">${L('No conversations yet')}</div>`}
 else if(tab==='g'){
  VL=GR.filter(g=>!q||B.NN(g.name).includes(q));
  h=VL.length?VL.map((g,i)=>`<div class="row" data-a="openg" data-i="${i}">${av(g.name,'',g.st==='inv'?'':'users')}<div class="in"><div class="nm">${esc(g.name)}</div><div class="mt">${g.st==='inv'?L('Invitation'):esc(g.last||fd(JSON.parse(g.mem).length+(g.adm?0:1))+' '+L('members'))}</div></div><div style="text-align:end">${g.lts?`<div class="mt">${when(g.lts)}</div>`:''}${g.un||g.st==='inv'?`<span class="badge">${g.st==='inv'?'!':fd(g.un)}</span>`:''}</div></div>`).join(''):`<div class="empty">${L('No groups yet')}</div>`}
 else{
  VL=SC;h=VL.length?VL.map((s,i)=>`<div class="row" data-a="sitem" data-i="${i}">${av('','','clock')}<div class="in"><div class="nm">${esc(tgtName(s))}</div><div class="mt">${esc(s.body.replace(/\n/g,' '))}</div></div><div style="text-align:end"><div class="mt">${fdt(s.ts)}</div><div class="mt" style="color:${s.st==='f'?'var(--rd)':'var(--mu)'}">${L(s.st==='p'?'Pending':s.st==='s'?'Sent':'Failed')}${s.rep?' ↻':''}</div></div></div>`).join(''):`<div class="empty">${L('No scheduled messages')}</div>`}
 $('#list').innerHTML=h}
const navb=x=>`<button data-a="tab" data-t="${x[0]}" class="${tab===x[0]?'on':''}">${ic(x[1])}<span>${L(x[2])}</span></button>`;
window.refresh=()=>{loadAll();render();if(cur)fill(false)};
window.nativeBack=()=>{if($('#vab').classList.contains('on')){closeVA();return true}if($('#shb').classList.contains('on')){closeSh();return true}if($('#pg2').classList.contains('on')){closePg2();return true}if($('#pg').classList.contains('on')){closePg();return true}return false};
window.nativeOpen=a=>{loadAll();openT({addr:a})};window.nativeOpenG=g=>{loadAll();openG(g)};window.nativeCompose=(n,b)=>{loadAll();openT({addr:n,body:b})};

/* ---------- pages ---------- */
function pg1(h,fx){$('#pgi').innerHTML=h;$('#pg').className='pg on'+(fx?' fx':'')}
function pg2(h){$('#pgi2').innerHTML=h;$('#pg2').classList.add('on')}
function closePg(){stopListen();$('#pg').classList.remove('on');cur=null;loadAll();render()}
function closePg2(){$('#pg2').classList.remove('on')}
const pt=t=>`<div class="pt"><button class="ib g" data-a="close2">${ic('back',22,1)}</button><span class="ptitle">${esc(L(t))}</span></div>`;

/* ---------- thread / group view ---------- */
function openT(o){cur={k:'t',tid:0,addr:o.addr||''};pg1(shell(),1);$('#ta').value=o.body||'';fill(true);cnt();if(!cur.addr)setTimeout(()=>$('#to')&&$('#to').focus(),350)}
function openG(gid){cur={k:'g',gid};pg1(shell(),1);fill(true)}
function shell(){const g=cur.k==='g';return`<div class="pt"><button class="ib g" data-a="close">${ic('back',22,1)}</button><div class="thh" data-a="tinfo"><div id="thav"></div><div style="min-width:0"><b id="thn"></b><small id="ths"></small></div></div>${g?'':`<button class="ib g" data-a="tcall">${ic('phone')}</button>`}<button class="ib g" data-a="tinfo">${ic('dots')}</button></div>
<div id="tofld"></div><div class="thr" id="thr"></div><div class="chips" id="chips"></div><div id="invb"></div>
<div id="qbar"></div><div class="comp" id="comp"><button class="ib g" data-a="dict" id="dictb">${ic('mic')}</button><div class="g tb"><button class="pb" data-a="attach">${ic('plus',22)}</button><textarea id="ta" rows="1" placeholder="${esc(L('Type a message…'))}"></textarea></div><button class="ib g simb" id="simb" data-a="sim" style="display:none"></button><button class="ib sendb" id="sendb" data-a="tsend" data-lp="sendlater">${ic('send',22,1)}</button></div><div class="cnt" id="cnt"></div>`}
function fill(first){
 const g=cur.k==='g';let M=[],G=null;
 if(g){G=GR.find(x=>x.id===cur.gid);if(!G){closePg();return}M=J('gmsgs',cur.gid)}
 else{if(!cur.tid&&cur.addr){const t=TH.find(t=>k10(t.addr)===k10(cur.addr));if(t)cur.tid=t.tid}
  M=cur.tid?J('messages',cur.tid).reverse():[];
  if(cur.tid){const t=TH.find(t=>t.tid===cur.tid);if(t&&t.un){NB.markRead(cur.tid);t.un=0}}}
 cur.M=M;
 const nm=g?G.name:(cur.addr?nameOf(cur.addr):L('New message'));
 $('#thav').innerHTML=av(nm,'sm',g?'users':'');$('#thn').innerHTML=disp(nm);simSync();
 $('#ths').innerHTML=g?fd(JSON.parse(G.mem).length+(G.adm?0:1))+' '+L('members'):(cur.addr&&nm!==cur.addr?disp(cur.addr):'');
 $('#tofld').innerHTML=(!g&&!cur.addr)?`<label class="fld"><span>${L('To')}</span><input id="to" placeholder="${esc(L('Name or number'))}" autocomplete="off"></label><div class="sugg" id="sugg"></div>`:'';
 const inv=g&&G.st==='inv';
 $('#comp').style.display=inv?'none':'flex';$('#invb').innerHTML=inv?`<div class="banner g"><span>${L('Invitation to this group. Accept to join.')}</span><span><button data-a="gacc">${L('Accept')}</button> <button data-a="gdec" style="background:var(--bd);color:var(--tx)">${L('Decline')}</button></span></div>`:'';
 const thr=$('#thr'),near=first||thr.scrollHeight-thr.scrollTop-thr.clientHeight<140;
 let h='',last='';
 M.forEach((m,i)=>{const out=g?m.o===1:m.type!==1,d=new Date(m.ts).toDateString();if(d!==last){h+=`<div class="day">${dayLabel(m.ts)}</div>`;last=d}
  const st=g||!out?'':m.type===5?' ⚠':(m.type===4||m.type===6)?' …':m.st===0?' ✓✓':' ✓';
  let body=m.body,qt='';const mq=body.match(/^↪ «([^»]*)»\n([\s\S]*)$/);if(mq){qt=`<div class="qt">${esc(mq[1])}</div>`;body=mq[2]}
  const big=/^(?:\p{Extended_Pictographic}\uFE0F?(?:\u200d\p{Extended_Pictographic}\uFE0F?)*\s?){1,3}$/u.test(body.trim()),sl=SIMS.length>1&&simSlot(m.sub)?' · SIM '+fd(simSlot(m.sub)):'';
  h+=`<div class="bub ${out?'me':'th g'}${big?' big':''}" data-a="bub" data-i="${i}">${g&&!out?`<div class="sn">${esc(nameOf(m.num))}</div>`:''}${qt}${esc(body)}<small>${tm(m.ts)}${sl}${st}</small></div>`});
 SC.filter(s=>s.st==='p'&&(g?s.kind==='g'&&s.tgt===cur.gid:s.kind==='n'&&cur.addr&&s.tgt.split(',').some(n=>k10(n)===k10(cur.addr)))).forEach(s=>{h+=`<div class="bub me pn" data-a="sitemid" data-id="${s.id}">⏰ ${fdt(s.ts)}${s.rep?' ↻':''}<br>${esc(s.body)}</div>`});
 thr.innerHTML=h;if(near)thr.scrollTop=thr.scrollHeight;
 if(first&&!g){S.pairs=S.pairs.concat(B.learn(M).filter(p=>!S.pairs.some(q=>q.t===p.t&&q.r===p.r))).slice(-300);save()}
 chips(M,nm,inv)}
function chips(M,nm,inv){const c=$('#chips'),l=M[M.length-1],inc=l&&(cur.k==='g'?l.o===0:l.type===1);
 if(!S.sr||inv||!inc){c.innerHTML='';return}
 const r=B.smart(l.body,{name:cur.k==='g'?'':nm,pairs:S.pairs});
 c.innerHTML=(r.code?`<button class="chip" data-a="cpcode" data-t="${esc(r.code)}">📋 ${L('Copy code')} ${esc(fd(r.code))}</button>`:'')+r.sug.map(t=>`<button class="chip" data-a="chip" data-t="${esc(t)}">${ic('spark',14)} ${esc(t)}</button>`).join('')}
function cnt(){const t=$('#ta');if(!t)return;t.style.height='auto';t.style.height=Math.min(t.scrollHeight,110)+'px';const l=t.value.length+(cur&&cur.k==='g'?17:0);$('#cnt').textContent=t.value?fd(l)+' · '+fd(segs(t.value+(cur.k==='g'?'x'.repeat(17):'')))+' '+L('SMS'):''}
function sugg(id,mode){const v=B.NN($('#'+id).value),raw=B.ND($('#'+id).value).replace(/[^\d+]/g,''),box=$('#sugg');if(!v){box.innerHTML='';return}
 const r=CT.filter(c=>B.NN(c.n).includes(v)||(raw.length>2&&c.p.includes(raw))).slice(0,6);
 box.innerHTML=r.map((c,i)=>`<div class="row" data-a="pick" data-m="${mode}" data-p="${esc(c.p)}" data-n="${esc(c.n)}">${av(c.n,'sm')}<div class="in"><div class="nm">${esc(c.n)}</div><div class="mt">${esc(c.p)}</div></div></div>`).join('')+(raw.length>=3?`<div class="row" data-a="pick" data-m="${mode}" data-p="${esc(raw)}" data-n="${esc(raw)}">${av('','sm','phone')}<div class="in"><div class="nm">${L('Use number')} ${esc(raw)}</div></div></div>`:'')}
function sendText(t){if(cur.k==='g')NB.gSendS(cur.gid,t,curSim());else{if(!cur.addr){toast(L('Enter a recipient'));return false}NB.sendS(cur.addr,t,curSim())}return true}
function qbar(){const q=$('#qbar');if(q)q.innerHTML=cur&&cur.quote?`<div class="qb g"><span>${ic('reply',16)} ${L('Replying to')}: ${esc(cur.quote)}</span><button data-a="qx">${ic('x',16)}</button></div>`:''}
function doSend(){const ta=$('#ta');let t=ta.value.trim();if(!t)return;if(cur.quote)t='↪ «'+cur.quote+'»\n'+t;if(!sendText(t))return;
 ta.value='';cur.quote='';qbar();cnt();$('#chips').innerHTML='';setTimeout(()=>{loadAll();fill(true)},350);setTimeout(()=>{loadAll();fill(false)},1500)}

/* ---------- group form ---------- */
function openGF(gid){const g=gid&&GR.find(x=>x.id===gid);GF={gid:gid||'',name:g?g.name:'',sel:new Set(g?JSON.parse(g.mem):[]),extra:[]};
 GF.sel.forEach(p=>{if(!CT.some(c=>c.p===p))GF.extra.push(p)});
 pg2(pt(g?'Edit group':'New group')+`<label class="fld"><span>${L('Group name')}</span><input id="gname" value="${esc(GF.name)}"></label>
 <div class="hint">${L('Only people who also have AUI SMS can see group messages. Messages travel as normal SMS, no internet needed.')}</div>
 <label class="search g" style="margin:8px 0"><span>${ic('search',20)}</span><input id="gq" placeholder="${esc(L('Search contacts…'))}" autocomplete="off"></label>
 <div class="dr"><input id="gnum" placeholder="+98…" inputmode="tel" style="flex:1;min-width:0"><button class="btn g" style="flex:none;padding:0 18px;height:42px" data-a="gaddnum">${L('Add number')}</button></div>
 <div class="sel" id="glist" style="flex:1"></div><div class="hint" id="gcount"></div><button class="bigbtn" data-a="gsave">${L(g?'Save':'Create group')}</button>`);gfList()}
function gfList(){const v=B.NN($('#gq')?$('#gq').value:''),all=GF.extra.map(p=>({n:p,p})).concat(CT);
 $('#glist').innerHTML=all.filter(c=>!v||B.NN(c.n).includes(v)||c.p.includes(v)).slice(0,250).map(c=>`<div class="row${GF.sel.has(c.p)?' on':''}" data-a="gpick" data-p="${esc(c.p)}">${av(c.n,'sm')}<div class="in"><div class="nm">${esc(c.n)}</div><div class="mt">${esc(c.p)}</div></div><span class="ck"></span></div>`).join('');gfCount()}
const gfCount=()=>{$('#gcount').textContent=fd(GF.sel.size)+' '+L('selected')};

/* ---------- schedule form ---------- */
function openSF(p){p=p||{};const n=new Date();let ts=p.ts||(Math.ceil((+n+36e5)/3e5)*3e5);
 SF={id:p.id||uid(),kind:p.kind||'',tgt:p.tgt||'',label:p.label||'',body:p.body||'',ts,rep:p.rep||''};
 pg2(pt('Schedule message')+`
 <div class="fld"><span>${L('To')}</span><b id="sfl" style="font-weight:500;font-size:17px">${esc(SF.label)||'—'}</b>
 ${SF.kind?'':`<input id="sto" placeholder="${esc(L('Name or number'))}" autocomplete="off"><div class="dr">${GR.filter(g=>g.st==='ok').map(g=>`<button class="chip" data-a="sgrp" data-id="${g.id}" data-n="${esc(g.name)}">${ic('users',14)} ${esc(g.name)}</button>`).join('')}</div><div class="sugg" id="sugg"></div>`}</div>
 <label class="fld"><span>${L('Message')}</span><textarea id="sbody">${esc(SF.body)}</textarea></label>
 <div class="sec">${L('When')}</div><div class="dr" id="spre"></div><div id="sfw"></div><div class="hint" id="sfd"></div>
 <div class="sec">${L('Repeat')}</div><div class="seg" id="srep"></div>
 ${NB.exactOk()?'':`<div class="banner g"><span>${L('Exact alarms are off, so timed messages may arrive a few minutes late.')}</span><button data-a="exact">${L('Allow')}</button></div>`}
 <button class="bigbtn" data-a="ssave">${L('Schedule')}</button>`);sfWhen();sfRep()}
function sfRep(){$('#srep').innerHTML=[['','Never'],['d','Daily'],['w','Weekly'],['m','Monthly'],['y','Yearly']].map(x=>`<button data-a="srep" data-v="${x[0]}" class="${SF.rep===x[0]?'on':''}">${L(x[1])}</button>`).join('')}
function sfWhen(){const n=new Date(),pre=pres();
 $('#spre').innerHTML=pre.map(x=>`<button class="chip" data-a="sw" data-t="${x[1]}">${x[0]}</button>`).join('');
 const d=new Date(SF.ts),pad=x=>String(x).padStart(2,'0'),tv=pad(d.getHours())+':'+pad(d.getMinutes());let c;
 if(jal()){const[jy,jm,jd]=B.g2j(d.getFullYear(),d.getMonth()+1,d.getDate()),cy=B.g2j(n.getFullYear(),n.getMonth()+1,n.getDate())[0];
  c=`<select class="wp" id="wd">${Array.from({length:31},(_,i)=>`<option value="${i+1}"${i+1===jd?' selected':''}>${fd(i+1)}</option>`).join('')}</select><select class="wp" id="wm">${JM.map((m,i)=>`<option value="${i+1}"${i+1===jm?' selected':''}>${m}</option>`).join('')}</select><select class="wp" id="wy">${Array.from({length:7},(_,i)=>cy+i).concat(jy<cy?[jy]:[]).map(y=>`<option value="${y}"${y===jy?' selected':''}>${fd(y)}</option>`).join('')}</select>`}
 else c=`<input class="wp" type="date" id="wdate" value="${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}">`;
 $('#sfw').innerHTML=`<div class="dr">${c}<input class="wp" type="time" id="wt" value="${tv}"></div>`;sfShow()}
const sfShow=()=>{$('#sfd').textContent=L('Will send on')+': '+full(SF.ts)};
function readW(){const tv=$('#wt').value.split(':');let y,m,d;if(jal())[y,m,d]=B.j2g(+$('#wy').value,+$('#wm').value,+$('#wd').value);else[y,m,d]=($('#wdate').value||'').split('-').map(Number);
 const t=new Date(y,m-1,d,+tv[0]||0,+tv[1]||0,0,0);if(!isNaN(+t)){SF.ts=+t;sfShow()}}

/* ---------- settings ---------- */
function openSet(){const o=(k,list)=>`<div class="seg">${list.map(x=>`<button data-a="sopt" data-k="${k}" data-v="${x[0]}" class="${String(S[k])===String(x[0])?'on':''}">${x[1]}</button>`).join('')}</div>`,
 tg=(k,t)=>`<div class="tgl"><span>${L(t)}</span><button class="tg${S[k]?' on':''}" data-a="stg" data-k="${k}"></button></div>`,def=NB.isDefault(),bl=J('blockedList');
 pg2(pt('Settings')+`<div class="card g"><div class="kv"><span>${L('Theme')}</span>${o('th',[['dark',L('Dark')],['light',L('Light')],['auto',L('Auto')]])}</div>
 <div class="kv"><span>${L('Accent')}</span>${o('acc',[['blue',L('Blue')],['green',L('Green')],['yellow',L('Yellow')],['mono',L('Mono')]])}</div><div class="kv"><span>${L('Language')}</span>${o('lg',[['fa','فارسی'],['en','English']])}</div>
 ${S.lg==='fa'?`<div class="kv"><span>${L('Calendar')}</span>${o('cal',[['p',L('Jalali')],['g',L('Gregorian')]])}</div>`:''}${tg('gl','Glass effect')}${tg('sr','Smart replies')}${tg('tts','Read aloud')}</div>
 <div class="card g"><div class="kv"><span>${L('Default SMS app')}</span>${def?L('Yes'):`<button class="btn pri" style="height:42px" data-a="defapp">${L('Make default')}</button>`}</div>
 <div class="kv"><span>${L('Blocked numbers')}</span>${bl.length?bl.map(n=>`<div class="hr" style="padding:6px 0"><span>${esc(n)}</span><button data-a="unblk" data-n="${esc(n)}" style="color:var(--ac)">${L('Unblock')}</button></div>`).join(''):L('None')}</div>
 <button class="li" data-a="clrpairs">${ic('trash',20)}${L('Forget learned replies')}</button></div>`)}

/* ---------- speech + voice assistant ---------- */
const tag=()=>S.lg==='fa'?'fa-IR':'en-US';
function listen(onText,onEnd,cont){if(NB.listen&&window.AuiBridge){window.onSpeech=o=>onText(o.text,o.final);window.onSpeechError=e=>onEnd(e);NB.listen(tag(),cont?'note':'cmd');return}
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){onEnd('na');return}const r=new SR();r.lang=tag();r.interimResults=true;r.continuous=!!cont;
 r.onresult=e=>{let part='';for(let i=e.resultIndex;i<e.results.length;i++){const x=e.results[i];if(x.isFinal)onText(x[0].transcript,true);else part+=x[0].transcript}if(part)onText(part,false)};r.onerror=e=>onEnd(e.error);r.onend=()=>onEnd('end');window.__sr=r;try{r.start()}catch(e){onEnd('na')}}
function stopListen(){dictOn=0;try{if(window.AuiBridge)NB.stopListen();else window.__sr&&window.__sr.stop()}catch(e){}$('#dictb')&&$('#dictb').classList.remove('on')}
function speak(t){if(!S.tts)return;try{if(window.AuiBridge)NB.speak(t,tag());else if(window.speechSynthesis){const u=new SpeechSynthesisUtterance(t);u.lang=tag();speechSynthesis.cancel();speechSynthesis.speak(u)}}catch(e){}}
let dictOn=0,dictBase='';
function dict(){if(dictOn){stopListen();return}const ta=$('#ta');dictOn=1;dictBase=ta.value?ta.value.replace(/\s*$/,' '):'';$('#dictb').classList.add('on');
 listen((t,f)=>{if(!dictOn)return;if(f){dictBase+=t+' ';ta.value=dictBase}else ta.value=dictBase+t;cnt()},e=>{if(!dictOn)return;if(['perm','not-allowed','na','service-not-allowed'].includes(e)){stopListen();toast(L(e==='na'?'Voice recognition is not available':'Microphone permission is needed'))}else setTimeout(()=>dictOn&&dict2(),350)},1)}
const dict2=()=>{dictOn=0;dict()};
let VA={on:0,pend:null};
const vIdle=()=>{$('#vm').classList.remove('on');$('#wave').classList.remove('on')};
function openVA(){$('#vab').classList.add('on');$('#vm').innerHTML=ic('mic',34);$('#vcl').textContent=L('Close');$('#vag').textContent=L('Speak');VA.pend=null;$('#vc').innerHTML='';$('#vt').textContent=L('How can I help you?');
 $('#vs').innerHTML=VEX[S.lg].map(t=>`<button class="vch g" data-a="vex" data-t="${esc(t)}">${ic('spark',18)}<span>${esc(t)}</span></button>`).join('');listenVA()}
function listenVA(){stopListen();VA.on=1;$('#vm').classList.add('on');$('#wave').classList.add('on');$('#vr').textContent=L('Listening…');
 listen((t,f)=>{if(!VA.on)return;$('#vt').textContent=t;if(f){VA.on=0;vIdle();runCmd(t)}},e=>{if(!VA.on)return;VA.on=0;vIdle();$('#vr').textContent=L(['perm','not-allowed','service-not-allowed'].includes(e)?'Microphone permission is needed':e==='na'?'Voice recognition is not available':'I did not catch that. Tap Speak to try again.')},0)}
function closeVA(){VA.on=0;VA.pend=null;stopListen();vIdle();$('#vab').classList.remove('on');try{window.speechSynthesis&&speechSynthesis.cancel()}catch(e){}}
function say(t,again){$('#vr').textContent=t;speak(t);if(again)setTimeout(()=>{if($('#vab').classList.contains('on')&&!VA.on)listenVA()},S.tts?2600:300)}
function runCmd(t){const c=B.parseCmd(t,{contacts:CT,groups:GR});
 if(VA.pend&&c&&c.t==='yes'){return vyes()}if(VA.pend&&c&&c.t==='no'){VA.pend=null;$('#vc').innerHTML='';return say(L('Cancelled'))}
 if(!c)return say(L('Sorry, I did not understand'));
 if(c.t==='send'){let body=c.body.replace(/^(?:بگو|که|بنویس|saying|that) /,''),w=B.parseWhen(body);if(w)body=w.rest.replace(/^(?:بگو|که|بنویس|saying|that|say) /,'');
  if(!c.c&&!c.g)return say(L('Contact not found')+': '+c.name);
  VA.pend={kind:c.g?'g':'n',tgt:c.g?c.g.id:c.c.p,label:c.g?c.g.name:c.c.n,body,ts:w?w.ts:0};
  $('#vc').innerHTML=`<div class="card g" style="margin-top:10px;text-align:start"><div class="kv"><span>${L('Message to')} ${esc(VA.pend.label)}${w?' · ⏰ '+esc(fdt(w.ts)):''}</span>${esc(body)}</div></div><div class="vx"><button class="g" data-a="vno">${L('Close')}</button><button class="pri" data-a="vyes">${L(w?'Schedule':'Send')}</button></div>`;
  return say(L('Message to')+' '+VA.pend.label+': '+body+'. '+L('Send it?'),true)}
 if(c.t==='read'){let L1=[];if(c.c)L1=TH.filter(x=>k10(x.addr)===k10(c.c.p)).slice(0,1).map(x=>[nameOf(x.addr),x.body]);else if(c.unread){L1=TH.filter(x=>x.un>0).slice(0,3).map(x=>[nameOf(x.addr),x.body]).concat(GR.filter(g=>g.un>0).slice(0,2).map(g=>[g.name,g.last||'']))}else L1=TH.slice(0,1).map(x=>[nameOf(x.addr),x.body]);
  if(!L1.length)return say(L('No new messages'));const s=L1.map(x=>L('Message from')+' '+x[0]+': '+x[1]).join('. ');$('#vc').innerHTML=`<div class="card g" style="margin-top:10px;text-align:start">${L1.map(x=>`<div class="kv"><span>${esc(x[0])}</span>${esc(x[1])}</div>`).join('')}</div>`;return say(s)}
 if(c.t==='reply'){const tg=cur&&cur.k==='g'?{kind:'g',tgt:cur.gid,label:(GR.find(g=>g.id===cur.gid)||{}).name}:cur&&cur.addr?{kind:'n',tgt:cur.addr,label:nameOf(cur.addr)}:TH[0]?{kind:'n',tgt:TH[0].addr,label:nameOf(TH[0].addr)}:null;
  if(!tg)return say(L('Nothing to reply to'));VA.pend=Object.assign({body:c.body,ts:0},tg);return say(L('Message to')+' '+tg.label+': '+c.body+'. '+L('Send it?'),true)}
 if(c.t==='open'){closeVA();if(c.g)return openG(c.g.id);if(c.c){const th=TH.find(x=>k10(x.addr)===k10(c.c.p));return openT({tid:th&&th.tid,addr:c.c.p})}tab='c';$('#q').value=c.name;return render()}
 if(c.t==='search'){closeVA();tab='c';$('#q').value=c.q;return render()}
 if(c.t==='newgroup'){closeVA();return openGF()}
 if(c.t==='sched'){closeVA();tab='s';return render()}
 say(L('Sorry, I did not understand'))}
function vyes(){const p=VA.pend;if(!p)return;VA.pend=null;$('#vc').innerHTML='';
 if(p.ts>Date.now()){NB.schedAdd(uid(),p.ts,p.kind,p.tgt,p.body,'',curSim());say(L('Scheduled for')+' '+fdt(p.ts))}
 else{p.kind==='g'?NB.gSendS(p.tgt,p.body,curSim()):NB.sendS(p.tgt,p.body,curSim());say(L('Message sent'))}
 setTimeout(()=>{loadAll();render()},500)}

/* ---------- actions ---------- */
function act(a,b){const d=b.dataset;switch(a){
 case 'tab':tab=d.t;HC=0;$('#hd').classList.remove('col');$('#list').scrollTop=0;render();break;case 'filt':filt=d.f;HC=0;$('#hd').classList.remove('col');render();break;
 case 'opent':{const t=VL[+d.i];openT({tid:t.tid,addr:t.addr});break}
 case 'openg':openG(VL[+d.i].id);break;
 case 'newm':openT({addr:''});break;
 case 'new':tab==='g'?openGF():tab==='s'?openSF():openT({addr:''});break;
 case 'menu':sheet('',[{t:L('Settings'),i:'gear',a:'set'},{t:L('Mark all as read'),i:'read',a:'markall'},{t:L('New group'),i:'users',a:'gnew'},{t:L('New schedule'),i:'clock',a:'snew'}]);break;
 case 'set':closeSh();openSet();break;case 'gnew':closeSh();openGF();break;case 'snew':closeSh();openSF();break;
 case 'markall':closeSh();TH.forEach(t=>{if(t.un)NB.markRead(t.tid)});setTimeout(window.refresh,200);break;
 case 'va':openVA();break;case 'vclose':closeVA();break;case 'vagain':VA.pend=null;listenVA();break;case 'vex':$('#vt').textContent=d.t;runCmd(d.t);break;case 'vyes':vyes();break;case 'vno':VA.pend=null;$('#vc').innerHTML='';say(L('Cancelled'));break;
 case 'closesh':closeSh();break;case 'close':closePg();break;case 'close2':closePg2();break;
 case 'defapp':closeSh();NB.requestDefault();break;case 'exact':NB.openExact();break;
 /* thread */
 case 'tsend':doSend();break;
 case 'sim':{const i=SIMS.findIndex(s=>s.sub===curSim()),n=SIMS[(i+1)%SIMS.length];S.sim=n.sub;save();simSync();toast('SIM '+fd(n.slot+1)+(n.name?' · '+n.name:''));break}
 case 'attach':sheet('',[{t:L('Contact'),i:'users',a:'attc'},{t:L('Date'),i:'clock',a:'attd'},{t:L('Location'),i:'pin',a:'attl'}]);break;
 case 'attc':closeSh();openPick();break;
 case 'pickc':{const c=PL[+d.i];closePg2();if(c)ins(c.n+': '+c.p);break}
 case 'attd':closeSh();SF={id:'',kind:'',tgt:'',label:'',body:'',ts:Math.ceil((Date.now()+36e5)/3e5)*3e5,rep:''};pg2(pt('Date')+`<div class="dr" id="spre"></div><div id="sfw"></div><div class="hint" id="sfd"></div><button class="bigbtn" data-a="dins">${L('Insert')}</button>`);sfWhen();break;
 case 'dins':closePg2();ins(full(SF.ts));break;
 case 'attl':closeSh();toast(L('Getting location…'));NB.location();break;
 case 'sendlater':sendLater();break;
 case 'sl':{closeSh();let t=$('#ta').value.trim();if(cur.quote)t='↪ «'+cur.quote+'»\n'+t;const g=cur.k==='g';NB.schedAdd(uid(),+d.t,g?'g':'n',g?cur.gid:cur.addr,t,'',curSim());$('#ta').value='';cur.quote='';qbar();cnt();toast(L('Scheduled')+': '+fdt(+d.t));setTimeout(window.refresh,300);break}
 case 'qr':closeSh();cur.quote=snip(cur.sel.body);qbar();$('#ta').focus();break;
 case 'qx':cur.quote='';qbar();break;
 case 'react':closeSh();if(sendText(d.e+' '+(S.lg==='fa'?'به':'to')+': «'+snip(cur.sel.body)+'»')){toast(L('Reaction sent'));setTimeout(()=>{loadAll();fill(true)},400)}break;
 case 'minfo':closeSh();{const m=cur.sel,s=simSlot(m.sub);toast(full(m.ts)+(s?' · SIM '+fd(s):''))}break;
 case 'rowmenu':{const t=VL[+d.i];if(!t)break;sheet(nameOf(t.addr),[{t:L(isPin(t.addr)?'Unpin':'Pin'),i:'pin',a:'rpin',d:{k:pinKey(t.addr)}},t.un?{t:L('Mark read'),i:'read',a:'rread',d:{tid:t.tid}}:null,{t:L('Block number'),i:'block',a:'rblk',d:{a:t.addr}},{t:L('Delete conversation'),i:'trash',a:'rdel',d:{tid:t.tid},r:1}].filter(Boolean));break}
 case 'rpin':closeSh();S.pins=S.pins.includes(d.k)?S.pins.filter(x=>x!==d.k):S.pins.concat(d.k);save();render();break;
 case 'rread':closeSh();NB.markRead(+d.tid);setTimeout(window.refresh,200);break;
 case 'rblk':closeSh();NB.setBlocked(d.a,true);toast(L('Blocked'));setTimeout(window.refresh,200);break;
 case 'rdel':closeSh();NB.delThread(+d.tid);toast(L('Deleted'));setTimeout(window.refresh,300);break;case 'dict':dict();break;
 case 'chip':{const ta=$('#ta');ta.value=d.t;ta.focus();cnt();break}
 case 'cpcode':NB.copy(d.t);toast(L('Copied'));break;
 case 'pick':if(d.m==='t'){cur.addr=d.p;fill(true)}else{SF.kind='n';SF.tgt=d.p;SF.label=d.n;$('#sfl').textContent=d.n;$('#sugg').innerHTML='';$('#sto').value=''}break;
 case 'tcall':NB.dial(cur.addr);break;
 case 'tinfo':if(cur.k==='g'){ginfo()}else if(cur.addr){const bl=J('blockedList').includes(k10(cur.addr)||cur.addr);sheet(nameOf(cur.addr),[{t:L('Call'),i:'phone',a:'tcall'},{t:L('Schedule message'),i:'clock',a:'tsch'},{t:L(bl?'Unblock number':'Block number'),i:'block',a:'tblock',d:{v:bl?0:1}},{t:L('Delete conversation'),i:'trash',a:'tdel',r:1}])}break;
 case 'tsch':closeSh();openSF(cur.k==='g'?{kind:'g',tgt:cur.gid,label:(GR.find(g=>g.id===cur.gid)||{}).name,body:$('#ta').value}:{kind:'n',tgt:cur.addr,label:nameOf(cur.addr),body:$('#ta').value});break;
 case 'tblock':closeSh();NB.setBlocked(cur.addr,d.v==='1');toast(L(d.v==='1'?'Blocked':'Unblocked'));if(d.v==='1')closePg();break;
 case 'tdel':closeSh();if(cur.tid)NB.delThread(cur.tid);toast(L('Deleted'));closePg();setTimeout(window.refresh,300);break;
 case 'bub':{const m=cur.M[+d.i];cur.sel=m;const it=[{t:L('Reply'),i:'reply',a:'qr'},{t:L('Copy'),i:'copy',a:'cp'},{t:L('Forward'),i:'fwd',a:'fw'},{t:L('Details'),i:'read',a:'minfo'}];if(cur.k==='t'&&m.type===5)it.unshift({t:L('Resend'),i:'send',a:'rs'});if(cur.k==='t')it.push({t:L('Delete'),i:'trash',a:'dm',r:1});sheet('',it,`<div class="react">${['❤️','👍','👎','😂','‼️','❓'].map(e=>`<button data-a="react" data-e="${e}">${e}</button>`).join('')}</div>`);break}
 case 'cp':closeSh();NB.copy(cur.sel.body);toast(L('Copied'));break;
 case 'fw':closeSh();{const b2=cur.sel.body;openT({addr:'',body:b2})}break;
 case 'rs':closeSh();NB.sendS(cur.addr,cur.sel.body,curSim());NB.delMsg(cur.sel.id);setTimeout(window.refresh,400);break;
 case 'dm':closeSh();NB.delMsg(cur.sel.id);setTimeout(window.refresh,200);break;
 case 'sitemid':{const s=SC.find(x=>x.id===d.id);if(s)sitem(s);break}
 /* groups */
 case 'gacc':NB.gAccept(cur.gid);setTimeout(window.refresh,200);break;
 case 'gdec':NB.gDel(cur.gid);closePg();break;
 case 'gedit':closeSh();closePg2();openGF(cur.gid);break;
 case 'gleave':closePg2();NB.gLeave(cur.gid);closePg();break;
 case 'gdelete':closePg2();NB.gDel(cur.gid);closePg();break;
 case 'gpick':{const p=d.p;GF.sel.has(p)?GF.sel.delete(p):GF.sel.add(p);b.classList.toggle('on');gfCount();break}
 case 'gaddnum':{const v=B.ND($('#gnum').value).replace(/[^\d+]/g,'');if(v.length>=5){GF.sel.add(v);if(!CT.some(c=>c.p===v)&&!GF.extra.includes(v))GF.extra.push(v);$('#gnum').value='';gfList()}break}
 case 'gsave':{const name=$('#gname').value.trim();if(!name||!GF.sel.size)return toast(L('Group name and at least one member are required'));if(GF.sel.size>15)return toast(L('Up to 15 members'));
  const arr=JSON.stringify([...GF.sel]);if(GF.gid){NB.gUpdate(GF.gid,name,arr);toast(L('Group updated'))}else{const id=NB.gNew(name,arr);toast(L('Group created'))}closePg2();tab='g';setTimeout(()=>{loadAll();render()},300);break}
 /* schedule */
 case 'sitem':sitem(SC[+d.i]);break;
 case 'sdel':closeSh();NB.schedDel(d.id);setTimeout(window.refresh,200);break;
 case 'snow':closeSh();{const s=SC.find(x=>x.id===d.id);if(s){s.kind==='g'?NB.gSendS(s.tgt,s.body,curSim()):s.tgt.split(',').forEach(n=>NB.sendS(n,s.body,curSim()));NB.schedDel(s.id);setTimeout(window.refresh,400)}}break;
 case 'sedit':closeSh();{const s=SC.find(x=>x.id===d.id);if(s)openSF({id:s.id,kind:s.kind,tgt:s.tgt,label:tgtName(s),body:s.body,ts:s.ts,rep:s.rep})}break;
 case 'sw':SF.ts=+d.t;sfWhen();break;
 case 'srep':SF.rep=d.v;sfRep();break;
 case 'sgrp':SF.kind='g';SF.tgt=d.id;SF.label=d.n;$('#sfl').textContent=d.n;break;
 case 'ssave':{SF.body=$('#sbody').value.trim();if(!SF.kind||!SF.tgt)return toast(L('Choose a recipient or group'));if(!SF.body)return toast(L('Write a message first'));if(SF.ts<Date.now()+1e4)return toast(L('Pick a time in the future'));
  NB.schedAdd(SF.id,SF.ts,SF.kind,SF.tgt,SF.body,SF.rep,curSim());toast(L('Scheduled'));if($('#ta'))$('#ta').value='';closePg2();setTimeout(window.refresh,300);break}
 /* settings */
 case 'sopt':S[d.k]=d.k==='gl'?+d.v:d.v;save();applySet();render();openSet();break;
 case 'stg':S[d.k]=S[d.k]?0:1;save();applySet();openSet();break;
 case 'unblk':NB.setBlocked(d.n,false);openSet();break;
 case 'clrpairs':S.pairs=[];save();toast(L('Done'));break}}
function openPick(){pg2(pt('Contact')+`<label class="search g" style="margin:8px 0"><span>${ic('search',20)}</span><input id="pq" placeholder="${esc(L('Search contacts…'))}" autocomplete="off"></label><div id="plist" style="flex:1"></div>`);pList()}
function pList(){const v=B.NN($('#pq').value);PL=CT.filter(c=>!v||B.NN(c.n).includes(v)||c.p.includes(v)).slice(0,200);$('#plist').innerHTML=PL.map((c,i)=>`<div class="row" data-a="pickc" data-i="${i}">${av(c.n,'sm')}<div class="in"><div class="nm">${esc(c.n)}</div><div class="mt">${disp(c.p)}</div></div></div>`).join('')}
function sendLater(){const t=$('#ta').value.trim();if(!t)return toast(L('Write a message first'));if(cur.k==='t'&&!cur.addr)return toast(L('Enter a recipient'));sheet(L('Send later'),pres().map(x=>({t:x[0],i:'clock',a:'sl',d:{t:x[1]}})).concat([{t:L('Pick date & time…'),i:'edit',a:'tsch'}]))}
window.onLoc=(a,b)=>{if(a==null)toast(L('Location unavailable'));else ins('📍 https://maps.google.com/?q='+Number(a).toFixed(6)+','+Number(b).toFixed(6))};
function sitem(s){sheet(tgtName(s),[{t:L('Send now'),i:'send',a:'snow',d:{id:s.id}},{t:L('Edit'),i:'edit',a:'sedit',d:{id:s.id}},{t:L('Cancel schedule'),i:'trash',a:'sdel',d:{id:s.id},r:1}])}
function ginfo(){const G=GR.find(x=>x.id===cur.gid);if(!G)return;const mem=JSON.parse(G.mem);
 pg2(pt(G.name)+`<div class="card g">${mem.map(p=>`<div class="kv"><b style="font-weight:500">${esc(nameOf(p))}</b>${G.adm&&k10(G.adm)===k10(p)?` · <span style="display:inline">${L('Admin')}</span>`:''}<span style="display:block;margin:0">${esc(p)}</span></div>`).join('')}</div>
 <div class="card g">${G.adm===''?`<button class="li" data-a="gedit">${ic('edit',20)}${L('Edit group')}</button>`:''}<button class="li red" data-a="gleave">${ic('x',20)}${L('Leave group')}</button><button class="li red" data-a="gdelete">${ic('trash',20)}${L('Delete group from this phone')}</button></div>`)}

let lpT=0,lpF=0,lpX=0,lpY=0;
document.addEventListener('pointerdown',e=>{lpF=0;const b=e.target.closest('[data-lp]');if(!b)return;lpX=e.clientX;lpY=e.clientY;clearTimeout(lpT);lpT=setTimeout(()=>{lpF=1;try{navigator.vibrate&&navigator.vibrate(15)}catch(x){}act(b.dataset.lp,b)},480)});
['pointerup','pointercancel'].forEach(t=>document.addEventListener(t,()=>clearTimeout(lpT)));
document.addEventListener('pointermove',e=>{if(Math.abs(e.clientX-lpX)>10||Math.abs(e.clientY-lpY)>10)clearTimeout(lpT)});
document.addEventListener('contextmenu',e=>{if(e.target.closest('[data-lp]'))e.preventDefault()});
(()=>{const l=$('#list'),h=$('#hd');l.addEventListener('scroll',()=>{const y=l.scrollTop,room=l.scrollHeight-l.clientHeight;if(!HC&&y>60&&room>h.offsetHeight+120){HC=1;h.classList.add('col')}else if(HC&&y<6){HC=0;h.classList.remove('col')}},{passive:true})})();
document.addEventListener('click',e=>{if(lpF){lpF=0;return}const b=e.target.closest('[data-a]');if(!b)return;act(b.dataset.a,b)});
document.addEventListener('input',e=>{const i=e.target.id;if(i==='to')sugg('to','t');else if(i==='sto')sugg('sto','s');else if(i==='ta')cnt();else if(i==='q')render();else if(i==='pq')pList();else if(i==='gq')gfList()});
document.addEventListener('change',e=>{if(e.target.classList.contains('wp'))readW()});
document.addEventListener('keydown',e=>{if(e.target.id==='gnum'&&e.key==='Enter')act('gaddnum',e.target)});
applySet();loadAll();render();
