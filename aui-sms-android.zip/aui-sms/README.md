# AUI SMS (Android) — پیامک آفلاین به سبک AUI Dialer

Glass-theme SMS app, same look as AUI Dialer. UI = `app/src/main/assets/` (`index.html`, `app.js`, `brain.js`); native layer = Kotlin
(WebView + JS bridge, SMS provider, receivers, AlarmManager, SQLite). **No INTERNET permission — everything runs on the device.**

## Build
- **Android Studio:** File → Open → this folder → Run ▶ (Android 10+).
- **GitHub:** push → Actions → "Build APK" → artifact `aui-sms-debug`.
- **CLI:** `gradle assembleDebug` (Gradle 8.7, JDK 17, SDK 34).

## First run
Allow SMS / Contacts / Notifications, then accept **"Set as default SMS app"** (needed to receive & store messages).

## Features
Real SMS app: conversations, search, unread, send/receive (multipart, Persian/UCS-2 aware counter), sent/delivered/failed status + resend,
notifications with inline reply / mark-read, quick reply to calls, block numbers, delete, forward, copy, contacts names, Jalali/Gregorian dates, dark/light/auto, blue/green, RTL.

1. **Groups (offline, SMS-based):** a group is a set of numbers. Each message is sent as a normal SMS to every member with a tiny header
   `[G:abc123:M:xyz12]`. Phones with AUI SMS hide the header and show one group chat; invite/accept, rename/add members (admin), leave.
   Phones without AUI SMS see the raw header text.
2. **Voice assistant:** "به علی پیام بده سلام", "پیام‌های جدید رو بخون", "جواب بده …", "باز کن علی", "جستجو …", "گروه جدید"; also dictation in the composer.
   For true offline recognition install the offline language pack: Settings → Google → Voice → Offline speech recognition (Persian / English).
3. **Smart replies:** on-device rule + retrieval engine (Persian & English) that reads the last incoming message and offers 3 replies;
   it also learns from your own past replies. OTP codes get a "copy code" chip. No cloud, no model download.
4. **Scheduled messages:** pick time (Jalali pickers), repeat daily/weekly/monthly/yearly, to a number or a group; survives reboot.
   Allow "Alarms & reminders" for exact timing.

## Notes / limits
- MMS (pictures) is not supported; delivery reports are treated as "delivered" when the carrier confirms.
- Fonts: drop `Vazirmatn.woff2` in `assets/fonts/` for the Vazirmatn look; otherwise system fonts are used.
